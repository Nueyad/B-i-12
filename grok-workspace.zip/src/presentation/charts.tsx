type Point = { label: string; value: number; display: string };

const fill = {
  gold: "bg-gold",
  sea: "bg-sea",
  leaf: "bg-leaf",
  coral: "bg-coral",
} as const;

export function ColumnChart({
  data,
  tone = "gold",
  caption,
}: {
  data: Point[];
  tone?: keyof typeof fill;
  caption: string;
}) {
  const max = Math.max(...data.map((item) => item.value), 1);
  return (
    <figure className="rounded-2xl border border-line bg-deep p-3" role="img" aria-label={caption}>
      <figcaption className="mb-2 text-sm font-semibold text-ink">{caption}</figcaption>
      <div className="flex h-44 items-end gap-3 md:h-52">
        {data.map((item, index) => (
          <div key={item.label} className="flex h-full min-w-0 flex-1 flex-col justify-end">
            <p className="mb-1 text-center text-sm font-semibold text-gold">{item.display}</p>
            <div className="flex h-4/5 items-end">
              <div
                className={`bar-up w-full rounded-t-lg ${fill[tone]}`}
                style={{
                  height: `${Math.max(8, (item.value / max) * 100)}%`,
                  animationDelay: `${index * 90}ms`,
                }}
              />
            </div>
            <p className="mt-2 text-center text-sm text-muted">{item.label}</p>
          </div>
        ))}
      </div>
    </figure>
  );
}

export function GroupedColumns({
  groups,
  series,
  caption,
}: {
  groups: { label: string; values: { key: string; value: number; display: string }[] }[];
  series: { key: string; name: string; tone: keyof typeof fill }[];
  caption: string;
}) {
  const max = Math.max(...groups.flatMap((group) => group.values.map((item) => item.value)), 1);
  return (
    <figure className="rounded-2xl border border-line bg-deep p-3" role="img" aria-label={caption}>
      <div className="mb-3 flex flex-wrap gap-3">
        {series.map((item) => (
          <span key={item.key} className="inline-flex items-center gap-2 text-sm text-muted">
            <span className={`size-3 rounded-sm ${fill[item.tone]}`} />
            {item.name}
          </span>
        ))}
      </div>
      <div className="flex h-52 items-end gap-2 md:h-64">
        {groups.map((group) => (
          <div key={group.label} className="flex h-full min-w-0 flex-1 flex-col justify-end">
            <div className="flex h-4/5 items-end gap-1">
              {group.values.map((item, index) => {
                const tone = series.find((entry) => entry.key === item.key)?.tone ?? "gold";
                return (
                  <div key={item.key} className="flex h-full min-w-0 flex-1 flex-col justify-end">
                    <p className="mb-1 text-center text-sm font-semibold text-ink">
                      {item.display}
                    </p>
                    <div
                      className={`bar-up w-full rounded-t-md ${fill[tone]}`}
                      style={{
                        height: `${Math.max(6, (item.value / max) * 100)}%`,
                        animationDelay: `${index * 70}ms`,
                      }}
                    />
                  </div>
                );
              })}
            </div>
            <p className="mt-2 text-center text-sm text-muted">{group.label}</p>
          </div>
        ))}
      </div>
    </figure>
  );
}

type Pair = { label: string; a: number; b: number; aDisplay: string; bDisplay: string };

export function DivergingPair({
  data,
  nameA,
  nameB,
  caption,
}: {
  data: Pair[];
  nameA: string;
  nameB: string;
  caption: string;
}) {
  const max = Math.max(...data.flatMap((item) => [Math.abs(item.a), Math.abs(item.b)]), 1);
  return (
    <figure className="rounded-2xl border border-line bg-deep p-4" role="img" aria-label={caption}>
      <div className="mb-3 flex flex-wrap gap-4 text-sm text-muted">
        <span className="inline-flex items-center gap-2">
          <span className="size-3 rounded-sm bg-gold" />
          {nameA}
        </span>
        <span className="inline-flex items-center gap-2">
          <span className="size-3 rounded-sm bg-sea" />
          {nameB}
        </span>
        <span>Mốc 0 ở giữa · cột về bên trái là mức giảm</span>
      </div>
      <div className="space-y-3">
        {data.map((item) => (
          <div key={item.label} className="grid grid-cols-[3.5rem_1fr] items-center gap-2">
            <p className="text-sm font-semibold text-muted">{item.label}</p>
            <div className="relative h-14">
              <div className="absolute inset-y-1 left-1/2 w-px bg-line" />
              <HBar value={item.a} max={max} display={item.aDisplay} tone="gold" edge="top-1" />
              <HBar value={item.b} max={max} display={item.bDisplay} tone="sea" edge="bottom-1" />
            </div>
          </div>
        ))}
      </div>
    </figure>
  );
}

function HBar({
  value,
  max,
  display,
  tone,
  edge,
}: {
  value: number;
  max: number;
  display: string;
  tone: "gold" | "sea";
  edge: "top-1" | "bottom-1";
}) {
  const negative = value < 0;
  const width = `${(Math.abs(value) / max) * 34}%`;
  const color = negative ? "bg-coral" : tone === "gold" ? "bg-gold" : "bg-sea";
  const grow = negative ? "bar-left" : "bar-right";
  return (
    <div
      className={`absolute ${edge} h-5`}
      style={negative ? { right: "50%", width } : { left: "50%", width }}
    >
      <div className={`h-full rounded-md ${color} ${grow}`} />
      <span
        className={`absolute top-0 left-full pl-1 text-sm font-semibold whitespace-nowrap ${
          negative ? "text-coral" : "text-ink"
        }`}
      >
        {display}
      </span>
    </div>
  );
}
