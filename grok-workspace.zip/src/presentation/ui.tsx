import type { ReactNode } from "react";

export function Shell({
  kicker,
  title,
  tone = "sea",
  source,
  children,
}: {
  kicker: string;
  title: string;
  tone?: "sea" | "leaf" | "gold";
  source?: string;
  children: ReactNode;
}) {
  const bar = tone === "leaf" ? "bg-leaf" : tone === "gold" ? "bg-gold" : "bg-sea";
  return (
    <section className="flex min-h-full flex-col px-4 py-4 md:px-10 md:py-6">
      <div className={`mb-3 h-1 w-14 rounded-full ${bar}`} />
      <p className="text-sm font-semibold tracking-widest text-gold">{kicker}</p>
      <h2 className="mt-1 max-w-5xl text-2xl font-bold leading-tight text-balance text-ink md:text-4xl">
        {title}
      </h2>
      <div className="mt-4 flex min-h-0 flex-1 flex-col gap-4">{children}</div>
      {source ? <p className="mt-4 text-sm text-muted">{source}</p> : null}
    </section>
  );
}

export function Points({ items }: { items: string[] }) {
  return (
    <ul className="space-y-3">
      {items.map((item) => (
        <li key={item} className="flex gap-3 text-base leading-snug text-ink md:text-lg">
          <span className="mt-2 size-2 shrink-0 rounded-full bg-gold" aria-hidden />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

export function Stat({
  value,
  unit,
  label,
}: {
  value: string;
  unit?: string;
  label: string;
}) {
  return (
    <div className="rounded-2xl border border-line bg-deep px-4 py-3">
      <p className="text-3xl font-bold text-gold md:text-4xl">{value}</p>
      {unit ? <p className="text-sm font-medium text-sea">{unit}</p> : null}
      <p className="mt-1 text-sm leading-snug text-muted md:text-base">{label}</p>
    </div>
  );
}

export function Remark({ children }: { children: ReactNode }) {
  return (
    <aside className="rounded-2xl border border-gold/40 bg-deep px-4 py-3">
      <p className="text-sm font-semibold text-gold">Nhận xét</p>
      <p className="mt-1 text-base leading-relaxed text-ink">{children}</p>
    </aside>
  );
}

export function SgkFigure({
  src,
  alt,
  caption,
}: {
  src: string;
  alt: string;
  caption: string;
}) {
  return (
    <figure className="overflow-hidden rounded-2xl border border-line bg-paper">
      <img src={src} alt={alt} className="max-h-[46vh] w-full object-contain" />
      <figcaption className="px-3 py-2 text-sm leading-snug text-paper-ink">{caption}</figcaption>
    </figure>
  );
}

export function DataTable({
  headers,
  rows,
  highlightCol,
}: {
  headers: string[];
  rows: string[][];
  highlightCol?: number;
}) {
  return (
    <div className="overflow-x-auto rounded-2xl border border-line">
      <table className="w-full min-w-lg border-collapse text-left text-sm md:text-base">
        <thead>
          <tr className="bg-deep text-gold">
            {headers.map((header) => (
              <th key={header} className="px-3 py-2 font-semibold whitespace-nowrap">
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, rowIndex) => (
            <tr key={row[0]} className={rowIndex % 2 ? "bg-deep/70" : "bg-card"}>
              {row.map((cell, cellIndex) => (
                <td
                  key={`${row[0]}-${cellIndex}`}
                  className={`px-3 py-2 whitespace-nowrap ${
                    cellIndex === 0
                      ? "font-semibold text-ink"
                      : cell.startsWith("−")
                        ? "font-semibold text-coral"
                        : cellIndex === highlightCol
                          ? "font-semibold text-gold"
                          : "text-ink"
                  }`}
                >
                  {cell}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function Chip({ children }: { children: ReactNode }) {
  return (
    <span className="rounded-full border border-line bg-deep px-3 py-1 text-sm font-medium text-ink md:text-base">
      {children}
    </span>
  );
}
