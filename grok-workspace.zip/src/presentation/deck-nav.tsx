import { createContext, useContext } from "react";

type DeckNavValue = {
  go: (index: number) => void;
  index: number;
};

export const DeckNav = createContext<DeckNavValue>({
  go: () => {},
  index: 0,
});

export function useDeckNav() {
  return useContext(DeckNav);
}
