import { useState, type ReactNode } from "react";
import { Compass, MapPin } from "lucide-react";
import { ColumnChart, DivergingPair, GroupedColumns } from "./charts";
import { useDeckNav } from "./deck-nav";
import { Chip, DataTable, Points, Remark, SgkFigure, Shell, Stat } from "./ui";

export type Fx = "rise" | "zoom" | "wipe" | "fade" | "drop";

export type Slide = {
  id: string;
  title: string;
  fx: Fx;
  notes: string;
  node: ReactNode;
};

const countries = [
  "Việt Nam",
  "Lào",
  "Cam-pu-chia",
  "Thái Lan",
  "Mi-an-ma",
  "Ma-lai-xi-a",
  "Xin-ga-po",
  "In-đô-nê-xi-a",
  "Bru-nây",
  "Phi-líp-pin",
];

function Cover() {
  return (
    <section className="relative flex min-h-full flex-col justify-end overflow-hidden">
      <img
        src="/sgk/hinh-12-2.jpg"
        alt=""
        className="map-zoom absolute inset-0 size-full object-cover opacity-45"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-ocean via-ocean/75 to-ocean/35" />
      <Compass className="absolute top-6 right-6 size-16 text-gold/80 md:top-10 md:right-10 md:size-20" />
      <div className="relative px-5 pt-16 pb-8 md:px-12 md:pb-12">
        <p className="text-sm font-semibold tracking-widest text-gold">ĐỊA LÍ 11 · BÀI 12</p>
        <h1 className="mt-3 max-w-4xl text-4xl font-bold leading-tight text-balance text-ink md:text-6xl">
          Kinh tế khu vực Đông Nam Á
        </h1>
        <p className="mt-4 max-w-2xl text-base leading-relaxed text-ink md:text-xl">
          Tình hình phát triển và các ngành kinh tế — nông nghiệp, lâm nghiệp, thủy sản, công
          nghiệp và dịch vụ.
        </p>
        <div className="mt-6 flex flex-wrap gap-2">
          {countries.map((name, index) => (
            <span
              key={name}
              className="chip-in rounded-full border border-line bg-ocean/70 px-3 py-1 text-sm text-ink"
              style={{ animationDelay: `${180 + index * 70}ms` }}
            >
              {name}
            </span>
          ))}
        </div>
        <p className="mt-6 text-sm text-muted">Nội dung và số liệu theo SGK Địa lí 11, Bài 12.</p>
      </div>
    </section>
  );
}

function Section({
  part,
  title,
  lead,
  tone,
}: {
  part: string;
  title: string;
  lead: string;
  tone: "sea" | "leaf" | "gold";
}) {
  const wash = tone === "leaf" ? "from-leaf/25" : tone === "gold" ? "from-gold/20" : "from-sea/25";
  return (
    <section className={`flex min-h-full flex-col justify-center bg-gradient-to-br ${wash} to-ocean px-6 py-10 md:px-14`}>
      <p className="text-sm font-semibold tracking-widest text-gold">{part}</p>
      <h2 className="mt-3 max-w-4xl text-4xl font-bold leading-tight text-balance text-ink md:text-6xl">
        {title}
      </h2>
      <p className="mt-5 max-w-2xl text-lg leading-relaxed text-ink md:text-2xl">{lead}</p>
    </section>
  );
}

const questions = [
  {
    level: "Nhận biết",
    prompt: "Năm 2020, quy mô GDP của Đông Nam Á khoảng bao nhiêu và chiếm khoảng bao nhiêu phần trăm GDP thế giới?",
    answer:
      "Khoảng 3 083,3 tỉ USD, chiếm khoảng 3,6% GDP toàn thế giới (Bảng 12.1, Ngân hàng Thế giới, 2022).",
  },
  {
    level: "Nhận biết",
    prompt: "Nêu cây lương thực quan trọng nhất và hai nước xuất khẩu gạo hàng đầu của khu vực.",
    answer:
      "Lúa gạo. In-đô-nê-xi-a có sản lượng lớn nhất khu vực (54,6 triệu tấn, thứ ba thế giới năm 2020). Thái Lan và Việt Nam là hai nước xuất khẩu gạo hàng đầu.",
  },
  {
    level: "Thông hiểu",
    prompt: "Vì sao tốc độ tăng GDP Đông Nam Á năm 2020 là −1,1%, trong khi năm 2019 là 4,5%?",
    answer:
      "Do ảnh hưởng của dịch bệnh. GDP giảm từ 3 314,1 tỉ USD (2019) xuống 3 083,3 tỉ USD (2020). Cùng năm, thế giới giảm −3,3%.",
  },
  {
    level: "Thông hiểu",
    prompt: "Dựa vào Bảng 12.2, nhận xét sản lượng lúa gạo và cao su của Đông Nam Á giai đoạn 2000–2020.",
    answer:
      "Lúa gạo: 152,1 triệu tấn (2000) → 196,7 (2010) → 190,1 (2020): tăng rồi giảm nhẹ. Cao su tăng liên tục: 5,3 → 8,0 → 10,7 triệu tấn, chiếm phần lớn sản lượng thế giới (thế giới năm 2020: 14,0 triệu tấn).",
  },
  {
    level: "Vận dụng",
    prompt:
      "Giải thích vì sao điện tử – tin học trở thành ngành mũi nhọn ở một số nước, và điều đó thể hiện hướng chuyển dịch nào của nền kinh tế?",
    answer:
      "Ngành phát triển ở Xin-ga-po, Thái Lan, Ma-lai-xi-a, Việt Nam nhờ lao động trẻ, trình độ kĩ thuật và vốn đầu tư nước ngoài; các nước tham gia chuỗi giá trị toàn cầu. Đó là biểu hiện chuyển dịch theo hướng công nghiệp hóa, hiện đại hóa.",
  },
];

function Quiz() {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <Shell kicker="PHẦN III · CỦNG CỐ" title="Câu hỏi" tone="gold">
      <div className="grid gap-3">
        {questions.map((item, index) => {
          const shown = open === index;
          return (
            <article key={item.prompt} className="rounded-2xl border border-line bg-deep px-4 py-3">
              <p className="text-sm font-semibold text-gold">
                Câu {index + 1} · {item.level}
              </p>
              <p className="mt-1 text-base leading-snug text-ink md:text-lg">{item.prompt}</p>
              {shown ? <p className="mt-2 text-base leading-relaxed text-sea">{item.answer}</p> : null}
              <button
                type="button"
                className="mt-2 text-sm font-semibold text-gold underline-offset-2 hover:underline"
                onClick={() => setOpen(shown ? null : index)}
              >
                {shown ? "Ẩn gợi ý" : "Hiện gợi ý"}
              </button>
            </article>
          );
        })}
      </div>
    </Shell>
  );
}

function Answers() {
  return (
    <Shell kicker="PHẦN III · GỢI Ý" title="Đáp án để thầy cô sử dụng" tone="gold" source="Đáp án bám số liệu và ý SGK. Không chấm máy móc từng chữ.">
      <div className="grid gap-3">
        {questions.map((item, index) => (
          <article key={item.prompt} className="rounded-2xl border border-line bg-card px-4 py-3">
            <p className="text-sm font-semibold text-gold">
              Câu {index + 1} · {item.level}
            </p>
            <p className="mt-1 text-base text-ink">{item.answer}</p>
          </article>
        ))}
      </div>
    </Shell>
  );
}

function EndSlide() {
  const { go } = useDeckNav();
  return (
    <section className="flex min-h-full flex-col items-start justify-center px-6 py-10 md:px-14">
      <p className="text-sm font-semibold tracking-widest text-gold">KHÉP LẠI BÀI 12</p>
      <h2 className="mt-3 max-w-4xl text-4xl font-bold leading-tight text-balance text-ink md:text-6xl">
        Đông Nam Á năng động, đang chuyển dịch — và vẫn còn chênh lệch.
      </h2>
      <p className="mt-5 max-w-2xl text-lg leading-relaxed text-ink md:text-xl">
        Nông nghiệp nhiệt đới giữ vai trò lương thực và xuất khẩu. Công nghiệp và dịch vụ ngày càng
        quyết định nhịp tăng trưởng.
      </p>
      <button
        type="button"
        onClick={() => go(0)}
        className="mt-8 rounded-full bg-gold px-5 py-3 text-base font-semibold text-paper-ink"
      >
        Về trang bìa
      </button>
    </section>
  );
}

function Mindmap() {
  const branches = [
    {
      title: "Tình hình",
      tone: "border-sea",
      lines: [
        "GDP 2020: 3 083,3 tỉ USD, khoảng 3,6% thế giới",
        "Tăng nhanh; năm 2020 giảm do dịch bệnh",
        "Chuyển dịch theo hướng công nghiệp hóa, hiện đại hóa",
      ],
    },
    {
      title: "Nông – lâm – thủy sản",
      tone: "border-leaf",
      lines: [
        "Lúa gạo, cây công nghiệp, cây ăn quả, chăn nuôi",
        "Gỗ tròn năm 2020: 302,0 triệu m³",
        "Thủy sản khoảng 25% sản lượng toàn cầu (2020)",
      ],
    },
    {
      title: "Công nghiệp",
      tone: "border-gold",
      lines: [
        "Điện tử – tin học là ngành mũi nhọn",
        "Chế biến thực phẩm, hàng tiêu dùng, khoáng sản",
        "Trung tâm: Băng Cốc, Gia-các-ta, TP. Hồ Chí Minh",
      ],
    },
    {
      title: "Dịch vụ",
      tone: "border-sea",
      lines: [
        "Thương mại xuất siêu; đối tác lớn: Trung Quốc, Hoa Kỳ, Hàn Quốc",
        "Đường bộ, đường sắt, đường biển, hàng không",
        "Tài chính và du lịch ngày càng quan trọng",
      ],
    },
  ];
  return (
    <Shell kicker="PHẦN III · TỔNG KẾT" title="Sơ đồ tư duy toàn bài" tone="gold">
      <div className="rounded-2xl border border-gold bg-deep px-4 py-3 text-center">
        <p className="text-xl font-bold text-gold md:text-2xl">Kinh tế khu vực Đông Nam Á</p>
        <p className="mt-1 text-sm text-muted md:text-base">
          Vị trí · Điều kiện tự nhiên · Tài nguyên · Lao động · Vốn đầu tư bên ngoài
        </p>
      </div>
      <div className="grid gap-3 md:grid-cols-2">
        {branches.map((branch) => (
          <article key={branch.title} className={`rounded-2xl border border-line border-t-4 ${branch.tone} bg-card px-4 py-3`}>
            <h3 className="text-lg font-bold text-ink">{branch.title}</h3>
            <ul className="mt-2 space-y-1">
              {branch.lines.map((line) => (
                <li key={line} className="text-sm leading-snug text-ink md:text-base">
                  {line}
                </li>
              ))}
            </ul>
          </article>
        ))}
      </div>
      <Remark>
        Thành tựu gắn với việc tận dụng lợi thế riêng, nhưng trình độ phát triển giữa các quốc gia còn
        chênh lệch lớn và khu vực đứng trước nhiều thách thức của toàn cầu hóa.
      </Remark>
    </Shell>
  );
}

export const slides: Slide[] = [
  {
    id: "cover",
    title: "Trang bìa",
    fx: "zoom",
    notes:
      "Mở bài bằng bản đồ khu vực. Nhấn mạnh trọng tâm là kinh tế Đông Nam Á, không phải bài giới thiệu chung. Mời học sinh nhìn các quốc gia hiện lần lượt rồi chuyển sang câu hỏi định hướng.",
    node: <Cover />,
  },
  {
    id: "question",
    title: "Câu hỏi định hướng",
    fx: "fade",
    notes:
      "Đọc nguyên câu dẫn trong SGK. Dừng lại ở hai câu hỏi: kinh tế phát triển ra sao, và các ngành có đặc điểm gì. Chưa trả lời hết — hẹn phần tổng kết.",
    node: (
      <Shell kicker="MỞ BÀI" title="Kinh tế Đông Nam Á đang đổi thay ra sao?" tone="sea">
        <blockquote className="rounded-2xl border border-line bg-deep px-5 py-4 text-lg leading-relaxed text-ink md:text-2xl">
          Những năm gần đây, kinh tế – xã hội khu vực Đông Nam Á có nhiều chuyển biến tích cực: vai
          trò và vị thế của khu vực ngày càng được nâng cao. Kinh tế khu vực Đông Nam Á phát triển ra
          sao? Các ngành kinh tế có đặc điểm gì nổi bật?
        </blockquote>
        <div className="grid gap-3 md:grid-cols-3">
          <Stat value="3 phần" label="Tình hình phát triển, các ngành kinh tế, rồi tổng kết." />
          <Stat value="SGK" label="Giữ nguyên thuật ngữ, địa danh, năm và đơn vị trong sách." />
          <Stat value="Nhận xét" label="Phần phân tích thêm luôn được ghi rõ, không trộn với số liệu SGK." />
        </div>
      </Shell>
    ),
  },
  {
    id: "roadmap",
    title: "Lộ trình bài học",
    fx: "rise",
    notes:
      "Chỉ ra ba chặng để học sinh biết bài dài nhưng có mạch. Nhắc quy ước: ý không gắn nhãn là của SGK; ô vàng “Nhận xét” là phân tích để hiểu bảng số liệu.",
    node: (
      <Shell kicker="ĐỊNH HƯỚNG" title="Ba chặng của bài học" tone="sea">
        <div className="grid gap-3 md:grid-cols-3">
          {[
            ["I", "Tình hình phát triển", "Quy mô GDP, tốc độ tăng, chuyển dịch cơ cấu và các yếu tố thúc đẩy."],
            ["II", "Các ngành kinh tế", "Nông – lâm – thủy sản, công nghiệp, rồi dịch vụ: thương mại, giao thông, tài chính, du lịch."],
            ["III", "Tổng kết", "Sơ đồ tư duy, câu hỏi nhận biết – thông hiểu – vận dụng và gợi ý đáp án."],
          ].map(([index, name, text]) => (
            <article key={index} className="rounded-2xl border border-line bg-card px-4 py-4">
              <p className="text-3xl font-bold text-gold">{index}</p>
              <h3 className="mt-2 text-xl font-bold text-ink">{name}</h3>
              <p className="mt-2 text-base leading-relaxed text-muted">{text}</p>
            </article>
          ))}
        </div>
        <Remark>
          Khi thuyết trình, bấm phím mũi tên hoặc phím cách để sang slide. Phím N mở ghi chú. Phím G mở lưới slide.
        </Remark>
      </Shell>
    ),
  },
  {
    id: "part-1",
    title: "Phần I",
    fx: "wipe",
    notes:
      "Chuyển phần. Một câu dẫn: trước khi đi vào từng ngành, xem khu vực lớn lên thế nào và vì sao năm 2020 bị hẫng.",
    node: (
      <Section
        part="PHẦN I"
        title="Tình hình phát triển kinh tế"
        lead="Quy mô GDP tăng nhanh trong hai thập niên, cơ cấu chuyển dịch — rồi dịch bệnh năm 2020 kéo tốc độ tăng trưởng xuống."
        tone="sea"
      />
    ),
  },
  {
    id: "gdp-hero",
    title: "Quy mô và vị thế năm 2020",
    fx: "drop",
    notes:
      "Đọc số trung tâm trước: khoảng 3 083 tỉ USD, bằng 3,6% GDP thế giới. Nhấn “khoảng” đúng lời SGK ở đoạn mở, còn số chi tiết 3 083,3 nằm ở Bảng 12.1. Nêu ngay Xin-ga-po, Thái Lan, Việt Nam là ví dụ các nước tăng trưởng cao.",
    node: (
      <Shell
        kicker="I · TÌNH HÌNH"
        title="Một nền kinh tế năng động bậc nhất thế giới"
        tone="sea"
        source="SGK Địa lí 11, Bài 12. Số liệu chi tiết: Bảng 12.1 — Ngân hàng Thế giới, 2022."
      >
        <div className="grid gap-3 md:grid-cols-3">
          <Stat value="3 083,3" unit="tỉ USD" label="Quy mô GDP Đông Nam Á năm 2020." />
          <Stat value="3,6%" unit="GDP thế giới" label="Vị thế của khu vực trong nền kinh tế toàn cầu." />
          <Stat value="4,5%" unit="năm 2019" label="Tốc độ tăng GDP trước khi dịch bệnh kéo năm 2020 đi xuống." />
        </div>
        <Points
          items={[
            "Trong những năm qua, quy mô GDP các nước Đông Nam Á tăng khá nhanh.",
            "Năm 2020, do ảnh hưởng của dịch bệnh, tốc độ tăng GDP giảm đáng kể.",
            "Những quốc gia có tốc độ tăng trưởng cao được SGK nêu: Xin-ga-po, Thái Lan, Việt Nam,…",
          ]}
        />
      </Shell>
    ),
  },
  {
    id: "table-121",
    title: "Bảng 12.1 — quy mô GDP",
    fx: "rise",
    notes:
      "Cho học sinh đọc bảng theo hàng Đông Nam Á trước, hàng thế giới sau. Cột biểu đồ chỉ vẽ Đông Nam Á để không bị lệch tỉ lệ với thế giới. Nhận xét 5,4 lần là phép tính từ 614,7 lên 3 314,1, cần nói rõ là nhận xét, không phải câu in sẵn trong sách.",
    node: (
      <Shell
        kicker="BẢNG 12.1"
        title="Quy mô GDP theo giá hiện hành"
        tone="gold"
        source="Đơn vị: tỉ USD. Nguồn: Ngân hàng Thế giới, 2022."
      >
        <div className="grid items-start gap-4 lg:grid-cols-2">
          <DataTable
            headers={["Năm", "2000", "2010", "2019", "2020"]}
            highlightCol={4}
            rows={[
              ["Đông Nam Á", "614,7", "2 017,3", "3 314,1", "3 083,3"],
              ["Thế giới", "33 830,9", "66 596,0", "87 652,9", "84 906,8"],
            ]}
          />
          <ColumnChart
            caption="GDP Đông Nam Á, tỉ USD"
            data={[
              { label: "2000", value: 614.7, display: "614,7" },
              { label: "2010", value: 2017.3, display: "2 017,3" },
              { label: "2019", value: 3314.1, display: "3 314,1" },
              { label: "2020", value: 3083.3, display: "3 083,3" },
            ]}
          />
        </div>
        <Remark>
          Từ năm 2000 đến năm 2019, GDP Đông Nam Á tăng từ 614,7 lên 3 314,1 tỉ USD — khoảng 5,4 lần.
          Năm 2020 quy mô giảm so với năm 2019. GDP thế giới cũng giảm: 87 652,9 xuống 84 906,8 tỉ USD.
        </Remark>
      </Shell>
    ),
  },
  {
    id: "growth",
    title: "Tốc độ tăng GDP",
    fx: "fade",
    notes:
      "Cột vàng là Đông Nam Á, cột xanh là thế giới. Học sinh thấy hầu hết các mốc khu vực cao hơn thế giới, và cả hai cùng âm năm 2020. Đông Nam Á −1,1% vẫn giảm ít hơn thế giới −3,3%. Đó là nhận xét từ bảng.",
    node: (
      <Shell
        kicker="BẢNG 12.1"
        title="Tốc độ tăng GDP của khu vực và thế giới"
        tone="gold"
        source="Đơn vị: %. Nguồn: Ngân hàng Thế giới, 2022. Cột dưới mốc 0 là mức giảm."
      >
        <DataTable
          headers={["Tốc độ tăng GDP (%)", "2000", "2010", "2019", "2020"]}
          rows={[
            ["Đông Nam Á", "7,0", "7,8", "4,5", "−1,1"],
            ["Thế giới", "4,5", "4,5", "2,6", "−3,3"],
          ]}
        />
        <DivergingPair
          nameA="Đông Nam Á"
          nameB="Thế giới"
          caption="Tốc độ tăng GDP, phần trăm"
          data={[
            { label: "2000", a: 7, b: 4.5, aDisplay: "7,0", bDisplay: "4,5" },
            { label: "2010", a: 7.8, b: 4.5, aDisplay: "7,8", bDisplay: "4,5" },
            { label: "2019", a: 4.5, b: 2.6, aDisplay: "4,5", bDisplay: "2,6" },
            { label: "2020", a: -1.1, b: -3.3, aDisplay: "−1,1", bDisplay: "−3,3" },
          ]}
        />
        <Remark>
          Ở các mốc 2000, 2010 và 2019, Đông Nam Á tăng nhanh hơn mức chung của thế giới. Năm 2020 cả
          hai đều âm; khu vực giảm ít hơn thế giới.
        </Remark>
      </Shell>
    ),
  },
  {
    id: "covid",
    title: "Năm 2020 và dịch bệnh",
    fx: "wipe",
    notes:
      "Đừng biến slide này thành bản tin dịch. Chỉ gắn đúng ý SGK: dịch bệnh làm tốc độ tăng GDP giảm đáng kể, và chỉ vào hai cặp số 4,5% xuống −1,1% và 3 314,1 xuống 3 083,3.",
    node: (
      <Shell kicker="I · NĂM 2020" title="Dịch bệnh kéo cả quy mô lẫn tốc độ tăng" tone="sea">
        <div className="grid gap-3 md:grid-cols-2">
          <Stat value="4,5% → −1,1%" label="Tốc độ tăng GDP Đông Nam Á, từ năm 2019 sang năm 2020." />
          <Stat value="3 314,1 → 3 083,3" unit="tỉ USD" label="Quy mô GDP khu vực giảm trong năm 2020." />
        </div>
        <Points
          items={[
            "SGK nêu rõ: năm 2020, do ảnh hưởng của dịch bệnh nên tốc độ tăng GDP giảm đáng kể.",
            "Thế giới cùng lúc giảm sâu hơn: tốc độ tăng GDP −3,3%, quy mô từ 87 652,9 xuống 84 906,8 tỉ USD.",
            "Một năm suy giảm không xóa thành tựu hai thập niên tăng trưởng trước đó.",
          ]}
        />
      </Shell>
    ),
  },
  {
    id: "shift",
    title: "Chuyển dịch cơ cấu và nguyên nhân",
    fx: "rise",
    notes:
      "Hai ý SGK: công nghiệp hóa, hiện đại hóa; một số nước chú trọng kinh tế tri thức, nghiên cứu và phát triển. Sau đó đọc năm lợi thế. Chênh lệch để sang slide sau, tránh nhồi.",
    node: (
      <Shell kicker="I · CƠ CẤU" title="Công nghiệp hóa, hiện đại hóa — và vì sao làm được" tone="sea">
        <Points
          items={[
            "Cơ cấu kinh tế của hầu hết các nước đang chuyển dịch theo hướng công nghiệp hóa, hiện đại hóa.",
            "Một số quốc gia chú trọng nền kinh tế tri thức, đẩy mạnh nghiên cứu và phát triển.",
            "Thành tựu có được nhờ các nước tận dụng vị trí địa lí, điều kiện tự nhiên và tài nguyên thiên nhiên.",
            "Thêm lực lượng lao động cùng khả năng thu hút nguồn đầu tư từ bên ngoài.",
          ]}
        />
        <div className="flex flex-wrap gap-2">
          {["Vị trí địa lí", "Điều kiện tự nhiên", "Tài nguyên", "Lao động", "Đầu tư bên ngoài"].map((item) => (
            <Chip key={item}>{item}</Chip>
          ))}
        </div>
      </Shell>
    ),
  },
  {
    id: "fig-121",
    title: "Hình 12.1 — cơ cấu GDP",
    fx: "zoom",
    notes:
      "Chiếu đúng biểu đồ SGK. Với Việt Nam, đọc xu hướng nông nghiệp giảm 19,3% xuống 12,7%, công nghiệp năm 2020 là 36,7%, dịch vụ quanh 40–42%. Với In-đô-nê-xi-a, công nghiệp giảm 44,1% xuống 38,3%, dịch vụ lên 44,4%. Nhắc nhóm thuế có trên biểu đồ nhưng chữ số quá nhỏ, không chép số nếu không chắc. Ảnh cột 2005 của In-đô-nê-xi-a cũng khó đọc nhóm nông nghiệp.",
    node: (
      <Shell
        kicker="HÌNH 12.1"
        title="Cơ cấu GDP In-đô-nê-xi-a và Việt Nam, 2005–2020"
        tone="gold"
        source="Nguồn biểu đồ: Ngân hàng Thế giới, 2022. Ảnh chụp từ SGK để đối chiếu."
      >
        <div className="grid items-start gap-4 lg:grid-cols-2">
          <SgkFigure
            src="/sgk/hinh-12-1.jpg"
            alt="Biểu đồ cơ cấu GDP của In-đô-nê-xi-a và Việt Nam giai đoạn 2005–2020"
            caption="Hình 12.1. Bốn nhóm: nông nghiệp, lâm nghiệp và thủy sản; công nghiệp và xây dựng; dịch vụ; thuế sản phẩm trừ trợ cấp sản phẩm."
          />
          <div className="flex flex-col gap-3">
            <DataTable
              headers={["Việt Nam (%)", "2005", "2010", "2015", "2020"]}
              rows={[
                ["Nông nghiệp, lâm nghiệp, thủy sản", "19,3", "15,4", "14,5", "12,7"],
                ["Công nghiệp và xây dựng", "38,1", "33,0", "34,3", "36,7"],
                ["Dịch vụ", "42,6", "40,6", "42,2", "41,8"],
              ]}
            />
            <Remark>
              Việt Nam: nông nghiệp giảm từ 19,3% (2005) xuống 12,7% (2020); công nghiệp và xây dựng năm
              2020 là 36,7%; dịch vụ giữ quanh 40–42%. In-đô-nê-xi-a: công nghiệp giảm từ 44,1% (2005)
              xuống 38,3% (2020), dịch vụ lên 44,4% (2020). Nhóm thuế có trên hình nhưng số in rất nhỏ —
              không chép khi chưa đối chiếu sách.
            </Remark>
          </div>
        </div>
      </Shell>
    ),
  },
  {
    id: "gaps",
    title: "Chênh lệch và thách thức",
    fx: "fade",
    notes:
      "Chốt phần I bằng đúng câu SGK: vẫn chênh lệch lớn về trình độ phát triển và nhiều thách thức trong toàn cầu hóa. Có thể hỏi: vì sao cùng khu vực mà Xin-ga-po khác Lào? Không cần trả lời hết.",
    node: (
      <Shell kicker="I · THÁCH THỨC" title="Cùng một khu vực, không cùng một nhịp" tone="sea">
        <Points
          items={[
            "Giữa các quốc gia vẫn có sự chênh lệch lớn về trình độ phát triển kinh tế.",
            "Khu vực đang phải đối mặt với nhiều thách thức trong bối cảnh toàn cầu hóa.",
            "Lợi thế về vị trí, tài nguyên, lao động và vốn ngoài không tự động san đều cho mọi nước.",
          ]}
        />
        <Remark>
          Phần II sẽ cho thấy sự chênh lệch ấy ngay trong cách từng ngành phân bố: nơi nào trồng lúa, nơi
          nào làm điện tử, nơi nào thành cảng hay trung tâm tài chính.
        </Remark>
      </Shell>
    ),
  },
  {
    id: "part-2",
    title: "Phần II",
    fx: "wipe",
    notes: "Chuyển màu sang nhóm ngành. Nhắc học sinh: ba nhóm sẽ đi theo thứ tự SGK, mỗi nhóm có vai trò, đặc điểm và ví dụ nước.",
    node: (
      <Section
        part="PHẦN II"
        title="Các ngành kinh tế"
        lead="Phần lớn các nước đang chuyển dịch cơ cấu, khai thác tốt hơn tiềm năng của từng ngành và nâng hiệu quả kinh tế."
        tone="leaf"
      />
    ),
  },
  {
    id: "agri-role",
    title: "Vai trò nông – lâm – thủy sản",
    fx: "rise",
    notes:
      "Ý then chốt: tỉ trọng trong GDP giảm nhưng vai trò không mất. Nhắc an ninh lương thực, việc làm và ngoại tệ. Một số nước đẩy nông nghiệp sản xuất hàng hóa.",
    node: (
      <Shell kicker="1 · NÔNG NGHIỆP, LÂM NGHIỆP VÀ THỦY SẢN" title="Nông nghiệp nhiệt đới, sản phẩm đa dạng" tone="leaf">
        <Points
          items={[
            "Đông Nam Á có nền nông nghiệp nhiệt đới với cơ cấu sản phẩm đa dạng.",
            "Tỉ trọng ngành trong cơ cấu GDP ngày càng giảm, nhưng vai trò vẫn quan trọng.",
            "Ngành vừa bảo đảm lương thực, thực phẩm, vừa tạo hàng xuất khẩu và nguồn ngoại tệ.",
            "Trồng trọt là ngành chính ở phần lớn các nước. Cây trồng chính: lúa gạo, cây công nghiệp và cây ăn quả.",
            "Một số quốc gia đang đẩy mạnh nông nghiệp sản xuất hàng hóa quy mô lớn.",
          ]}
        />
      </Shell>
    ),
  },
  {
    id: "rice",
    title: "Lúa gạo",
    fx: "fade",
    notes:
      "Đây là cây lương thực truyền thống, quan trọng nhất. Nhấn sản lượng tăng giúp giải quyết lương thực và còn xuất khẩu. Số 54,6 triệu tấn và thứ ba thế giới là của In-đô-nê-xi-a năm 2020. Thái Lan và Việt Nam là hai nước xuất khẩu hàng đầu — không nhầm với nước có sản lượng lớn nhất.",
    node: (
      <Shell kicker="1 · TRỒNG TRỌT" title="Lúa gạo: lương thực và mặt hàng xuất khẩu" tone="leaf">
        <div className="grid gap-3 md:grid-cols-3">
          <Stat value="54,6" unit="triệu tấn" label="Sản lượng lúa của In-đô-nê-xi-a năm 2020 — lớn nhất khu vực." />
          <Stat value="Thứ 3" unit="thế giới, 2020" label="Vị trí của In-đô-nê-xi-a về sản lượng lúa gạo." />
          <Stat value="2 nước" label="Thái Lan và Việt Nam — xuất khẩu gạo hàng đầu thế giới." />
        </div>
        <Points
          items={[
            "Lúa gạo là cây lương thực truyền thống và quan trọng nhất của khu vực.",
            "Sản lượng lúa ngày càng tăng nên các nước đã cơ bản giải quyết nhu cầu lương thực và có xuất khẩu.",
          ]}
        />
      </Shell>
    ),
  },
  {
    id: "crops",
    title: "Cây công nghiệp",
    fx: "rise",
    notes:
      "Bốn cây đứng hàng đầu thế giới: cao su, cọ dầu, cà phê, hồ tiêu. Gắn đúng nước: cao su bốn nước; cọ dầu chỉ In-đô-nê-xi-a và Ma-lai-xi-a; cà phê và hồ tiêu thêm Việt Nam, Thái Lan.",
    node: (
      <Shell kicker="1 · CÂY CÔNG NGHIỆP" title="Đứng hàng đầu thế giới về cao su, cọ dầu, cà phê, hồ tiêu" tone="leaf">
        <div className="grid gap-3 md:grid-cols-2">
          {[
            ["Cao su", "Ma-lai-xi-a, In-đô-nê-xi-a, Thái Lan, Việt Nam"],
            ["Cọ dầu", "In-đô-nê-xi-a và Ma-lai-xi-a"],
            ["Cà phê", "Việt Nam, In-đô-nê-xi-a, Ma-lai-xi-a, Thái Lan"],
            ["Hồ tiêu", "Việt Nam, In-đô-nê-xi-a, Ma-lai-xi-a, Thái Lan"],
          ].map(([name, where]) => (
            <article key={name} className="rounded-2xl border border-line bg-card px-4 py-3">
              <h3 className="text-xl font-bold text-leaf">{name}</h3>
              <p className="mt-1 text-base leading-snug text-ink">{where}</p>
            </article>
          ))}
        </div>
        <p className="text-base text-muted">Các cây này có giá trị xuất khẩu cao.</p>
      </Shell>
    ),
  },
  {
    id: "fruit",
    title: "Cây ăn quả và chăn nuôi",
    fx: "fade",
    notes:
      "Ăn quả: xoài, chôm chôm, sầu riêng, dừa, chuối — hầu hết các nước, là hàng xuất khẩu đáng kể. Chăn nuôi được chú trọng vì đời sống nâng lên và hiệu quả kinh tế. Trâu bò, lợn, gia cầm gắn đúng nhóm nước trong SGK.",
    node: (
      <Shell kicker="1 · ĂN QUẢ VÀ CHĂN NUÔI" title="Vừa đa dạng trong khu vực, vừa có hàng xuất khẩu" tone="leaf">
        <div className="grid gap-3 md:grid-cols-2">
          <article className="rounded-2xl border border-line bg-card px-4 py-3">
            <h3 className="text-lg font-bold text-ink">Cây ăn quả</h3>
            <p className="mt-2 text-base leading-relaxed text-ink">
              Xoài, chôm chôm, sầu riêng, dừa, chuối… được trồng ở hầu hết các nước. Đây là mặt hàng xuất
              khẩu mang lại nguồn thu ngoại tệ đáng kể.
            </p>
          </article>
          <article className="rounded-2xl border border-line bg-card px-4 py-3">
            <h3 className="text-lg font-bold text-ink">Chăn nuôi</h3>
            <ul className="mt-2 space-y-2 text-base leading-snug text-ink">
              <li>Trâu, bò: Mi-an-ma, In-đô-nê-xi-a, Thái Lan, Việt Nam.</li>
              <li>Lợn: Việt Nam, Phi-líp-pin, Thái Lan, In-đô-nê-xi-a.</li>
              <li>Gia cầm: phổ biến ở hầu hết các nước.</li>
            </ul>
          </article>
        </div>
        <Remark>
          SGK gắn sự chú trọng chăn nuôi với chất lượng cuộc sống được nâng lên và hiệu quả kinh tế cao.
        </Remark>
      </Shell>
    ),
  },
  {
    id: "forest",
    title: "Lâm nghiệp",
    fx: "rise",
    notes:
      "Ngành quan trọng với In-đô-nê-xi-a, Thái Lan, Mi-an-ma, Việt Nam. Hai số gỗ tròn: 299,1 triệu m³ năm 2000 và 302,0 triệu m³ năm 2020, khoảng 7,7% thế giới. Nhấn cả khai thác lẫn trồng rừng, khoanh nuôi, vườn quốc gia, khu bảo tồn — không chỉ có chặt gỗ.",
    node: (
      <Shell kicker="1 · LÂM NGHIỆP" title="Khai thác gỗ đi cùng bảo vệ rừng" tone="leaf" source="Sản lượng gỗ tròn theo SGK Địa lí 11, Bài 12.">
        <div className="grid gap-3 md:grid-cols-3">
          <Stat value="299,1" unit="triệu m³" label="Gỗ tròn khai thác năm 2000." />
          <Stat value="302,0" unit="triệu m³" label="Gỗ tròn khai thác năm 2020." />
          <Stat value="7,7%" unit="thế giới" label="Tỉ lệ gỗ tròn của khu vực năm 2020." />
        </div>
        <Points
          items={[
            "Lâm nghiệp quan trọng với In-đô-nê-xi-a, Thái Lan, Mi-an-ma và Việt Nam.",
            "Các nước tăng cường trồng rừng, khoanh nuôi rừng tự nhiên.",
            "Đồng thời thành lập vườn quốc gia và khu bảo tồn thiên nhiên.",
          ]}
        />
      </Shell>
    ),
  },
  {
    id: "fish",
    title: "Thủy sản",
    fx: "fade",
    notes:
      "Điều kiện thuận lợi, vừa khai thác vừa nuôi. Năm 2020 đóng góp khoảng 25% sản lượng thủy sản toàn cầu. Nước sản xuất lớn: In-đô-nê-xi-a, Việt Nam, Phi-líp-pin. Thách thức là nguồn lợi suy giảm. Thái Lan, Việt Nam, Phi-líp-pin chú trọng nuôi trồng. Sản phẩm là mặt hàng xuất khẩu chủ lực.",
    node: (
      <Shell kicker="1 · THỦY SẢN" title="Khoảng một phần tư thủy sản toàn cầu" tone="leaf">
        <div className="grid gap-3 md:grid-cols-2">
          <Stat value="~25%" unit="năm 2020" label="Đông Nam Á đóng góp vào tổng sản lượng thủy sản toàn cầu." />
          <Stat value="3 nước lớn" label="In-đô-nê-xi-a, Việt Nam và Phi-líp-pin — các nước sản xuất thủy sản lớn trong khu vực." />
        </div>
        <Points
          items={[
            "Khu vực có nhiều điều kiện thuận lợi; các nước đã đầu tư vốn, công nghệ, kĩ thuật cho đánh bắt và nuôi trồng.",
            "Sản phẩm thủy sản là mặt hàng xuất khẩu chủ lực: tôm, cá ngừ đại dương, cá da trơn,…",
            "Khai thác đang đi theo hướng công nghiệp hóa, hiện đại hóa và bền vững vì nguồn lợi suy giảm, ảnh hưởng đời sống của hàng chục triệu người.",
            "Thái Lan, Việt Nam, Phi-líp-pin chú trọng nuôi thủy sản để đáp ứng nhu cầu và bảo vệ nguồn lợi tự nhiên.",
          ]}
        />
      </Shell>
    ),
  },
  {
    id: "map-122",
    title: "Hình 12.2 — bản đồ nông lâm thủy sản",
    fx: "zoom",
    notes:
      "Dừng ở bản đồ. Hướng dẫn đọc chú giải: lúa gạo, vùng trồng trọt, rừng, cây công nghiệp, chăn nuôi, khai thác thủy sản. Không yêu cầu nhớ từng chấm. Câu hỏi SGK: trình bày sự phát triển và phân bố dựa trên mục 1 và hình này.",
    node: (
      <Shell kicker="HÌNH 12.2" title="Phân bố nông nghiệp, lâm nghiệp và thủy sản năm 2020" tone="leaf">
        <SgkFigure
          src="/sgk/hinh-12-2.jpg"
          alt="Bản đồ phân bố nông nghiệp, lâm nghiệp và thủy sản khu vực Đông Nam Á năm 2020"
          caption="Hình 12.2. Bản đồ SGK — đối chiếu chú giải lúa gạo, cây công nghiệp, chăn nuôi, rừng và khai thác thủy sản. Ảnh chụp từ sách."
        />
      </Shell>
    ),
  },
  {
    id: "table-122",
    title: "Bảng 12.2 — sản lượng",
    fx: "rise",
    notes:
      "Đây là biểu đồ gợi ý cho bài tập vẽ biểu đồ từ Bảng 12.2. Ba chỉ tiêu tách ba biểu đồ vì đơn vị và quy mô khác nhau. Nhận xét lúa khoảng 1/4 thế giới và cao su khoảng 3/4 là phép tính từ bảng, phải nói là nhận xét. Đàn lợn tăng rồi giảm.",
    node: (
      <Shell
        kicker="BẢNG 12.2"
        title="Lúa gạo, cao su và đàn lợn, 2000–2020"
        tone="leaf"
        source="Nguồn: Tổ chức Lương thực và Nông nghiệp Liên hợp quốc, 2022. Ba biểu đồ ở slide sau."
      >
        <DataTable
          headers={["Chỉ tiêu", "2000", "2010", "2020"]}
          rows={[
            ["Lúa gạo Đông Nam Á (triệu tấn)", "152,1", "196,7", "190,1"],
            ["Lúa gạo thế giới (triệu tấn)", "598,7", "694,5", "769,2"],
            ["Cao su Đông Nam Á (triệu tấn)", "5,3", "8,0", "10,7"],
            ["Cao su thế giới (triệu tấn)", "7,1", "10,8", "14,0"],
            ["Đàn lợn Đông Nam Á (triệu con)", "52,4", "72,4", "65,6"],
            ["Đàn lợn thế giới (triệu con)", "898,7", "971,1", "937,5"],
          ]}
        />
        <Remark>
          Tính từ bảng: năm 2020 lúa gạo khu vực bằng khoảng 1/4 sản lượng thế giới (190,1 / 769,2). Cao su
          khu vực bằng khoảng 3/4 thế giới (10,7 / 14,0). Đàn lợn tăng mạnh tới năm 2010 rồi giảm vào năm 2020.
        </Remark>
      </Shell>
    ),
  },
  {
    id: "chart-122",
    title: "Biểu đồ Bảng 12.2",
    fx: "fade",
    notes:
      "Ba biểu đồ chỉ vẽ Đông Nam Á, mỗi biểu đồ một thang đo riêng — vì lúa, cao su và đàn lợn khác đơn vị, khác quy mô. Thế giới nằm ở bảng slide trước để đối chiếu. Đây là gợi ý cho bài tập vẽ biểu đồ từ Bảng 12.2.",
    node: (
      <Shell kicker="BẢNG 12.2 · BIỂU ĐỒ" title="Đông Nam Á qua ba mốc 2000 – 2010 – 2020" tone="leaf" source="Số liệu Bảng 12.2. Mỗi cột một thang đo riêng.">
        <div className="grid gap-3 lg:grid-cols-3">
          <ColumnChart
            tone="gold"
            caption="Lúa gạo — triệu tấn"
            data={[
              { label: "2000", value: 152.1, display: "152,1" },
              { label: "2010", value: 196.7, display: "196,7" },
              { label: "2020", value: 190.1, display: "190,1" },
            ]}
          />
          <ColumnChart
            tone="leaf"
            caption="Cao su — triệu tấn"
            data={[
              { label: "2000", value: 5.3, display: "5,3" },
              { label: "2010", value: 8, display: "8,0" },
              { label: "2020", value: 10.7, display: "10,7" },
            ]}
          />
          <ColumnChart
            tone="coral"
            caption="Đàn lợn — triệu con"
            data={[
              { label: "2000", value: 52.4, display: "52,4" },
              { label: "2010", value: 72.4, display: "72,4" },
              { label: "2020", value: 65.6, display: "65,6" },
            ]}
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Chip>Vàng: lúa gạo (triệu tấn)</Chip>
          <Chip>Xanh lá: cao su (triệu tấn)</Chip>
          <Chip>Cam: đàn lợn (triệu con)</Chip>
        </div>
      </Shell>
    ),
  },
  {
    id: "industry-role",
    title: "Vai trò công nghiệp",
    fx: "wipe",
    notes:
      "Chuyển sắc từ xanh lá sang vàng – xanh biển để sang công nghiệp. Vai trò: chuyển dịch cơ cấu, việc làm, xuất khẩu. Bốn hướng ngành và ba trung tâm lớn.",
    node: (
      <Shell kicker="2 · CÔNG NGHIỆP" title="Đòn bẩy của công nghiệp hóa" tone="gold">
        <Points
          items={[
            "Công nghiệp thúc đẩy chuyển dịch cơ cấu theo hướng công nghiệp hóa, hiện đại hóa.",
            "Ngành tạo nhiều việc làm và tăng nguồn thu ngoại tệ từ xuất khẩu.",
            "Các ngành quan trọng: điện tử – tin học, chế biến thực phẩm, sản xuất hàng tiêu dùng và khai thác khoáng sản.",
            "Một số trung tâm công nghiệp lớn: Băng Cốc (Thái Lan), Gia-các-ta (In-đô-nê-xi-a), Thành phố Hồ Chí Minh (Việt Nam).",
          ]}
        />
      </Shell>
    ),
  },
  {
    id: "electronics",
    title: "Điện tử – tin học",
    fx: "rise",
    notes:
      "Ngành mũi nhọn của Xin-ga-po, Thái Lan, Ma-lai-xi-a, Việt Nam. Ba lợi thế: lao động trẻ, trình độ kĩ thuật, vốn FDI. Kết luận SGK: đang tham gia chuỗi giá trị toàn cầu.",
    node: (
      <Shell kicker="2 · ĐIỆN TỬ – TIN HỌC" title="Ngành mũi nhọn trong chuỗi giá trị toàn cầu" tone="gold">
        <div className="flex flex-wrap gap-2">
          {["Xin-ga-po", "Thái Lan", "Ma-lai-xi-a", "Việt Nam"].map((name) => (
            <Chip key={name}>{name}</Chip>
          ))}
        </div>
        <Points
          items={[
            "Công nghiệp điện tử – tin học đang trở thành ngành mũi nhọn của nhiều nước trong khu vực.",
            "Ngành dựa trên lao động trẻ, có trình độ kĩ thuật và thu hút đầu tư nước ngoài.",
            "Hiện nay các nước trong khu vực đang tham gia vào chuỗi giá trị toàn cầu trong lĩnh vực này.",
          ]}
        />
      </Shell>
    ),
  },
  {
    id: "food-mining",
    title: "Chế biến, hàng tiêu dùng và khoáng sản",
    fx: "fade",
    notes:
      "Chế biến thực phẩm và hàng tiêu dùng dựa vào nguyên liệu nhiệt đới, thị trường lớn, lao động dồi dào; phân bố rộng, nhất là các nước đông dân. Thiếc hơn một nửa sản lượng thế giới. Dầu khí nêu đúng bốn nước, Bru-nây có trong nhóm này.",
    node: (
      <Shell kicker="2 · CHẾ BIẾN VÀ KHOÁNG SẢN" title="Từ nông sản nhiệt đới đến thiếc, dầu mỏ, khí" tone="gold">
        <div className="grid gap-3 md:grid-cols-2">
          <article className="rounded-2xl border border-line bg-card px-4 py-3">
            <h3 className="text-lg font-bold text-ink">Chế biến thực phẩm và hàng tiêu dùng</h3>
            <p className="mt-2 text-base leading-relaxed text-ink">
              Dựa trên sản phẩm nông nghiệp nhiệt đới, thị trường tiêu thụ lớn và lao động dồi dào. Phân bố
              ở tất cả các nước, nhất là các nước đông dân: In-đô-nê-xi-a, Thái Lan, Việt Nam, Phi-líp-pin.
            </p>
          </article>
          <article className="rounded-2xl border border-line bg-card px-4 py-3">
            <h3 className="text-lg font-bold text-ink">Khai thác khoáng sản</h3>
            <p className="mt-2 text-base leading-relaxed text-ink">
              Khai thác thiếc chiếm hơn một nửa sản lượng thế giới: Ma-lai-xi-a, In-đô-nê-xi-a, Mi-an-ma,
              Thái Lan. Dầu mỏ và khí tự nhiên phát triển mạnh ở Bru-nây, Ma-lai-xi-a, In-đô-nê-xi-a, Việt Nam.
            </p>
          </article>
        </div>
      </Shell>
    ),
  },
  {
    id: "map-123",
    title: "Hình 12.3 — bản đồ công nghiệp",
    fx: "zoom",
    notes:
      "Chiếu bản đồ gốc. Đọc chú giải cùng học sinh: trung tâm công nghiệp, dầu mỏ, khí, thiếc, điện tử – tin học, cảng, sân bay. Câu hỏi SGK yêu cầu trình bày và giải thích sự phát triển ngành công nghiệp từ mục 2 và hình này.",
    node: (
      <Shell kicker="HÌNH 12.3" title="Phân bố công nghiệp Đông Nam Á năm 2020" tone="gold">
        <SgkFigure
          src="/sgk/hinh-12-3.jpg"
          alt="Bản đồ phân bố công nghiệp khu vực Đông Nam Á năm 2020"
          caption="Hình 12.3. Bản đồ SGK. Chú giải gồm trung tâm công nghiệp, khoáng sản, điện tử – tin học, cảng biển và sân bay. Ảnh chụp từ sách."
        />
      </Shell>
    ),
  },
  {
    id: "fig-124",
    title: "Hình 12.4 — điện tử ở Việt Nam",
    fx: "fade",
    notes:
      "Ảnh minh họa đúng hình SGK: dây chuyền sản xuất điện tử tại Việt Nam. Nối lại ba lợi thế vừa nêu — lao động trẻ, kĩ thuật, vốn nước ngoài — chứ không mô tả máy móc ngoài sách.",
    node: (
      <Shell kicker="HÌNH 12.4" title="Sản xuất sản phẩm điện tử ở Việt Nam" tone="gold">
        <div className="grid items-center gap-4 lg:grid-cols-2">
          <SgkFigure
            src="/sgk/hinh-12-4.jpg"
            alt="Công nhân trên dây chuyền sản xuất sản phẩm điện tử ở Việt Nam"
            caption="Hình 12.4. Sản xuất sản phẩm điện tử ở Việt Nam. Ảnh trong SGK."
          />
          <Points
            items={[
              "Việt Nam nằm trong nhóm nước mà điện tử – tin học đang trở thành ngành mũi nhọn.",
              "Hình cho thấy lao động trực tiếp trên dây chuyền — đúng lợi thế lao động trẻ, có kĩ thuật.",
              "Ngành gắn với vốn đầu tư nước ngoài và chuỗi giá trị toàn cầu, không chỉ tiêu thụ trong nước.",
            ]}
          />
        </div>
      </Shell>
    ),
  },
  {
    id: "services",
    title: "Vai trò dịch vụ",
    fx: "wipe",
    notes:
      "Mở nhóm dịch vụ: vai trò ngày càng quan trọng, thể hiện ở tỉ trọng lao động và giá trị trong GDP đều tăng. Bốn phân ngành sẽ đi lần lượt: thương mại, giao thông, tài chính, du lịch.",
    node: (
      <Section
        part="3 · DỊCH VỤ"
        title="Tỉ trọng lao động và giá trị trong GDP đều tăng"
        lead="Các nước chú ý phát triển dịch vụ. Bốn hướng cần nhớ: thương mại, giao thông vận tải, tài chính – ngân hàng và du lịch."
        tone="sea"
      />
    ),
  },
  {
    id: "trade",
    title: "Thương mại",
    fx: "rise",
    notes:
      "Nội thương: siêu thị, trung tâm thương mại, thương mại điện tử. Bốn nước nội thương mạnh. Em có biết: nội khối ASEAN 500 lên 630 tỉ USD. Ngoại thương then chốt. Đối tác: Trung Quốc, Hoa Kỳ, Hàn Quốc. Xuất: nông sản, thủy sản, khoáng sản, dệt may. Nhập: máy móc, hàng tiêu dùng. Hoạt động ngoại thương mạnh nhất: Xin-ga-po và Thái Lan. Nội vùng khoảng 25% tổng trị giá xuất nhập khẩu. Hầu hết các nước xuất siêu.",
    node: (
      <Shell kicker="3 · THƯƠNG MẠI" title="Điều tiết sản xuất, nối khu vực với thế giới" tone="sea">
        <div className="grid gap-3 md:grid-cols-2">
          <article className="rounded-2xl border border-line bg-card px-4 py-3">
            <h3 className="text-lg font-bold text-ink">Nội thương</h3>
            <p className="mt-2 text-base leading-relaxed text-ink">
              Phát triển nhanh: siêu thị, trung tâm thương mại, thương mại điện tử. Mạnh ở Xin-ga-po,
              In-đô-nê-xi-a, Ma-lai-xi-a và Thái Lan.
            </p>
          </article>
          <article className="rounded-2xl border border-line bg-card px-4 py-3">
            <h3 className="text-lg font-bold text-ink">Ngoại thương</h3>
            <p className="mt-2 text-base leading-relaxed text-ink">
              Vai trò then chốt. Đối tác lớn nhất: Trung Quốc, Hoa Kỳ, Hàn Quốc. Xuất nông sản, thủy sản,
              khoáng sản, dệt may. Nhập máy móc, hàng tiêu dùng. Xin-ga-po và Thái Lan có hoạt động ngoại
              thương phát triển nhất.
            </p>
          </article>
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <Stat value="500 → 630" unit="tỉ USD" label="Thương mại nội khối ASEAN, từ năm 2010 đến năm 2020." />
          <Stat value="~25%" label="Thương mại giữa các nước trong khu vực so với tổng trị giá xuất nhập khẩu toàn khu vực." />
        </div>
      </Shell>
    ),
  },
  {
    id: "table-123",
    title: "Bảng 12.3 — xuất nhập khẩu",
    fx: "fade",
    notes:
      "Đọc bảng rồi mới nhìn cột. Cả ba năm xuất lớn hơn nhập. Xuất siêu tính được: 125,5; 124,5 và 149,7 tỉ USD. Nói rõ đây là nhận xét tính từ bảng, khớp câu SGK: hầu hết các nước xuất siêu.",
    node: (
      <Shell
        kicker="BẢNG 12.3"
        title="Trị giá xuất khẩu và nhập khẩu hàng hóa, dịch vụ"
        tone="sea"
        source="Đơn vị: tỉ USD. Giai đoạn 2010–2020. Nguồn: Ngân hàng Thế giới, 2022."
      >
        <div className="grid items-start gap-4 lg:grid-cols-2">
          <DataTable
            headers={["Trị giá", "2010", "2015", "2020"]}
            rows={[
              ["Xuất khẩu", "1 244,9", "1 506,0", "1 676,3"],
              ["Nhập khẩu", "1 119,4", "1 381,5", "1 526,6"],
            ]}
          />
          <GroupedColumns
            caption="Xuất khẩu và nhập khẩu Đông Nam Á, tỉ USD"
            series={[
              { key: "x", name: "Xuất khẩu", tone: "gold" },
              { key: "m", name: "Nhập khẩu", tone: "sea" },
            ]}
            groups={[
              {
                label: "2010",
                values: [
                  { key: "x", value: 1244.9, display: "1 244,9" },
                  { key: "m", value: 1119.4, display: "1 119,4" },
                ],
              },
              {
                label: "2015",
                values: [
                  { key: "x", value: 1506, display: "1 506,0" },
                  { key: "m", value: 1381.5, display: "1 381,5" },
                ],
              },
              {
                label: "2020",
                values: [
                  { key: "x", value: 1676.3, display: "1 676,3" },
                  { key: "m", value: 1526.6, display: "1 526,6" },
                ],
              },
            ]}
          />
        </div>
        <Remark>
          Cả ba mốc, xuất khẩu lớn hơn nhập khẩu. Xuất siêu tính từ bảng: 125,5 tỉ USD (2010), 124,5
          (2015) và 149,7 (2020). Đúng với nhận định SGK: hầu hết các nước có trị giá xuất khẩu lớn hơn
          nhập khẩu.
        </Remark>
      </Shell>
    ),
  },
  {
    id: "road-rail",
    title: "Đường bộ và đường sắt",
    fx: "rise",
    notes:
      "Vai trò chung của giao thông: sản xuất, đời sống, hội nhập, thu hút đầu tư. Đường bộ hiện đại hóa nhanh. Hành lang Đông – Tây nối Việt Nam, Lào, Thái Lan, Mi-an-ma. AH1, AH2, AH3. Đường sắt phổ biến ở lục địa, tổng 20 000 km năm 2020; Xin-ga-po và Ma-lai-xi-a nâng cấp cao tốc.",
    node: (
      <Shell kicker="3 · GIAO THÔNG" title="Đường bộ và đường sắt nối sản xuất với hội nhập" tone="sea">
        <Points
          items={[
            "Giao thông được chú ý phát triển, hiện đại hóa để phục vụ sản xuất, đời sống và hợp tác với nhà đầu tư nước ngoài.",
            "Đường bộ đầu tư mạnh. Hành lang Đông – Tây nối Việt Nam, Lào, Thái Lan, Mi-an-ma.",
            "Các tuyến đường cao tốc Xuyên Á AH1, AH2, AH3 là những liên kết quan trọng trong khu vực.",
            "Đường sắt khá phổ biến ở Đông Nam Á lục địa. Tổng chiều dài 20 000 km (năm 2020).",
            "Xin-ga-po và Ma-lai-xi-a đang nâng cấp mạng lưới lên đường sắt cao tốc.",
          ]}
        />
        <svg viewBox="0 0 640 36" className="w-full text-gold" aria-hidden>
          <line x1="8" y1="18" x2="632" y2="18" className="lane" stroke="currentColor" strokeWidth="3" />
        </svg>
        <div className="flex flex-wrap gap-2">
          {["Việt Nam", "Lào", "Thái Lan", "Mi-an-ma", "AH1", "AH2", "AH3"].map((item) => (
            <Chip key={item}>{item}</Chip>
          ))}
        </div>
      </Shell>
    ),
  },
  {
    id: "sea-air",
    title: "Đường biển và hàng không",
    fx: "zoom",
    notes:
      "Đường biển rất quan trọng với khu vực biển đảo. 2,8 tỉ tấn năm 2019; hơn 500 cảng năm 2020. Đọc tên cảng đúng SGK. Xin-ga-po là một trong những cảng nhộn nhịp nhất thế giới. Hàng không: năm sân bay lớn được nêu.",
    node: (
      <Shell kicker="3 · BIỂN VÀ HÀNG KHÔNG" title="Cảng biển và sân bay của một khu vực hướng biển" tone="sea">
        <div className="grid gap-3 md:grid-cols-2">
          <Stat value="2,8 tỉ tấn" label="Khối lượng vận chuyển đường biển năm 2019." />
          <Stat value="> 500 cảng" label="Số cảng biển của khu vực năm 2020." />
        </div>
        <div className="grid gap-3 md:grid-cols-2">
          <article className="rounded-2xl border border-line bg-card px-4 py-3">
            <h3 className="text-lg font-bold text-ink">Cảng biển lớn</h3>
            <p className="mt-2 text-base leading-relaxed text-ink">
              Hải Phòng, Sài Gòn (Việt Nam), Y-an-gun (Mi-an-ma), Băng Cốc (Thái Lan), Xin-ga-po.
              Xin-ga-po là một trong những cảng biển nhộn nhịp nhất thế giới.
            </p>
          </article>
          <article className="rounded-2xl border border-line bg-card px-4 py-3">
            <h3 className="text-lg font-bold text-ink">Sân bay lớn</h3>
            <p className="mt-2 text-base leading-relaxed text-ink">
              Chan-gi (Xin-ga-po), Xu-va-na-bu-mi (Thái Lan), Cu-a-la Lăm-pơ (Ma-lai-xi-a), Tân Sơn Nhất
              và Nội Bài (Việt Nam).
            </p>
          </article>
        </div>
        <svg viewBox="0 0 640 36" className="w-full text-sea" aria-hidden>
          <path d="M8 28 C 160 4, 480 4, 632 28" className="lane" fill="none" stroke="currentColor" strokeWidth="3" />
        </svg>
      </Shell>
    ),
  },
  {
    id: "finance",
    title: "Tài chính – ngân hàng",
    fx: "rise",
    notes:
      "Ngành đang trong quá trình phát triển và hội nhập, là động lực thúc đẩy kinh tế. Lợi thế: lao động và thị trường quy mô lớn. Năm trung tâm: Xin-ga-po, Cu-a-la Lăm-pơ, Băng Cốc, Gia-các-ta, Thành phố Hồ Chí Minh.",
    node: (
      <Shell kicker="3 · TÀI CHÍNH – NGÂN HÀNG" title="Động lực hội nhập của những trung tâm lớn" tone="sea">
        <Points
          items={[
            "Tài chính – ngân hàng đang trong quá trình phát triển và hội nhập với thế giới.",
            "Ngành dần trở thành động lực thúc đẩy kinh tế các nước trong khu vực.",
            "Thuận lợi về nguồn lao động và thị trường quy mô lớn đang thúc đẩy sự phát triển.",
          ]}
        />
        <div className="flex flex-wrap gap-2">
          {["Xin-ga-po", "Cu-a-la Lăm-pơ", "Băng Cốc", "Gia-các-ta", "Thành phố Hồ Chí Minh"].map((name) => (
            <Chip key={name}>{name}</Chip>
          ))}
        </div>
      </Shell>
    ),
  },
  {
    id: "tourism",
    title: "Du lịch — vai trò và số liệu",
    fx: "fade",
    notes:
      "Năm 2019: đóng góp hơn 393 tỉ USD vào GDP khu vực và thu hút khoảng 10% lượng khách du lịch quốc tế toàn cầu. Bốn nước du lịch mạnh. Nhấn năm 2019, không lấy năm dịch để thay số sách.",
    node: (
      <Shell kicker="3 · DU LỊCH" title="Điểm đến phổ biến của khách quốc tế" tone="sea" source="Số liệu năm 2019 theo SGK Địa lí 11, Bài 12.">
        <div className="grid gap-3 md:grid-cols-2">
          <Stat value="> 393" unit="tỉ USD, năm 2019" label="Du lịch đóng góp vào GDP của khu vực." />
          <Stat value="~10%" unit="khách quốc tế" label="Đông Nam Á thu hút khoảng 10% tổng lượng khách du lịch quốc tế toàn cầu." />
        </div>
        <p className="text-base text-ink md:text-lg">
          Các quốc gia có ngành du lịch phát triển mạnh: Thái Lan, Việt Nam, In-đô-nê-xi-a, Xin-ga-po.
        </p>
      </Shell>
    ),
  },
  {
    id: "places",
    title: "Điểm du lịch tiêu biểu",
    fx: "zoom",
    notes:
      "Đọc sáu địa điểm đúng nước. Ảnh là Hình 12.5, bãi biển Ba-li, không phải một bãi biển khác. Câu luyện tập SGK gợi ý tìm hiểu thêm một địa điểm — có thể giao về nhà, không mở rộng trên slide.",
    node: (
      <Shell kicker="HÌNH 12.5" title="Sáu điểm du lịch SGK nêu tên" tone="sea">
        <div className="grid items-start gap-4 lg:grid-cols-2">
          <SgkFigure
            src="/sgk/hinh-12-5.jpg"
            alt="Bãi biển Ba-li, In-đô-nê-xi-a"
            caption="Hình 12.5. Bãi biển Ba-li, In-đô-nê-xi-a. Ảnh trong SGK."
          />
          <ul className="grid gap-2">
            {[
              ["Ăng-co Vát", "Cam-pu-chia"],
              ["Vịnh Hạ Long", "Việt Nam"],
              ["Ba-li", "In-đô-nê-xi-a"],
              ["Ba-gan", "Mi-an-ma"],
              ["Cu-a-la Lăm-pơ", "Ma-lai-xi-a"],
              ["Băng Cốc", "Thái Lan"],
            ].map(([place, country]) => (
              <li key={place} className="flex items-center gap-3 rounded-2xl border border-line bg-card px-3 py-2">
                <MapPin className="size-5 shrink-0 text-gold" />
                <span className="text-base text-ink md:text-lg">
                  <span className="font-semibold">{place}</span>
                  <span className="text-muted"> — {country}</span>
                </span>
              </li>
            ))}
          </ul>
        </div>
      </Shell>
    ),
  },
  {
    id: "mind",
    title: "Sơ đồ tư duy",
    fx: "wipe",
    notes:
      "Dùng sơ đồ để khép bài, không thêm kiến thức mới. Đọc bốn nhánh, rồi một câu về lợi thế và thách thức. Có thể che nhánh và gọi học sinh nhắc lại.",
    node: <Mindmap />,
  },
  {
    id: "quiz",
    title: "Câu hỏi củng cố",
    fx: "rise",
    notes:
      "Năm câu theo mức nhận biết, thông hiểu, vận dụng. Có thể bấm Hiện gợi ý ngay trên slide hoặc chuyển sang slide đáp án. Không để đáp án hiện sẵn khi mới mở.",
    node: <Quiz />,
  },
  {
    id: "answers",
    title: "Gợi ý đáp án",
    fx: "fade",
    notes:
      "Slide dành cho người dạy. Có thể bỏ qua khi trình chiếu trước lớp và chỉ mở nếu cần chốt. Đáp án cũng nằm trong ghi chú của slide câu hỏi.",
    node: <Answers />,
  },
  {
    id: "end",
    title: "Kết thúc",
    fx: "zoom",
    notes:
      "Một câu chốt rồi dừng. Không mở rộng thành bài quảng bá du lịch. Mời học sinh về nhà quan sát lại Hình 12.2 và 12.3 trong sách.",
    node: <EndSlide />,
  },
];
