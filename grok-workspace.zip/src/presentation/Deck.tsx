import { useCallback, useEffect, useRef, useState, type PointerEvent } from "react";
import { ChevronLeft, ChevronRight, LayoutGrid, Maximize2, StickyNote, X } from "lucide-react";
import { DeckNav } from "./deck-nav";
import { slides } from "./slides";

export function Deck() {
  const [index, setIndex] = useState(0);
  const [notes, setNotes] = useState(false);
  const [overview, setOverview] = useState(false);
  const start = useRef<{ x: number; y: number } | null>(null);
  const total = slides.length;
  const slide = slides[index] ?? slides[0];

  const go = useCallback((nextIndex: number) => {
    setIndex(Math.min(total - 1, Math.max(0, nextIndex)));
  }, [total]);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
      if (event.key === "ArrowRight" || event.key === "PageDown" || event.key === " ") {
        event.preventDefault();
        if (!overview) go(index + 1);
      } else if (event.key === "ArrowLeft" || event.key === "PageUp" || event.key === "Backspace") {
        event.preventDefault();
        if (!overview) go(index - 1);
      } else if (event.key === "Home") {
        go(0);
      } else if (event.key === "End") {
        go(total - 1);
      } else if (event.key === "n" || event.key === "N") {
        setNotes((value) => !value);
      } else if (event.key === "g" || event.key === "G") {
        setOverview((value) => !value);
      } else if (event.key === "Escape") {
        setOverview(false);
        setNotes(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go, index, overview, total]);

  const onPointerDown = (event: PointerEvent) => {
    if ((event.target as HTMLElement).closest("button, a, input, textarea")) return;
    start.current = { x: event.clientX, y: event.clientY };
  };
  const onPointerUp = (event: PointerEvent) => {
    if (!start.current || overview) return;
    const dx = event.clientX - start.current.x;
    const dy = event.clientY - start.current.y;
    start.current = null;
    if (Math.abs(dx) < 56 || Math.abs(dx) < Math.abs(dy)) return;
    go(index + (dx < 0 ? 1 : -1));
  };

  const fullscreen = async () => {
    try {
      if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
      else await document.exitFullscreen();
    } catch {
      /* Khung xem trước có thể không cho phép toàn màn hình. */
    }
  };

  return (
    <DeckNav.Provider value={{ go, index }}>
      <div className="atlas flex h-dvh flex-col text-ink" onPointerDown={onPointerDown} onPointerUp={onPointerUp}>
        <header className="flex items-center justify-between gap-3 px-4 py-2 md:px-6">
          <p className="text-sm font-semibold tracking-wide text-gold">Địa lí 11 · Bài 12</p>
          <p className="truncate text-sm text-muted">{slide.title}</p>
        </header>
        <div className="h-1 bg-deep" aria-hidden>
          <div
            className="h-full bg-gold transition-[width] duration-500"
            style={{ width: `${((index + 1) / total) * 100}%` }}
          />
        </div>
        <div className="flex min-h-0 flex-1 flex-col lg:flex-row">
          <main className="relative min-h-0 flex-1 overflow-hidden" aria-live="polite">
            <div key={slide.id} className={`fx-${slide.fx} h-full overflow-y-auto`}>
              {slide.node}
            </div>
            {overview ? (
              <div className="absolute inset-0 z-20 overflow-y-auto bg-ocean/95 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <p className="text-lg font-bold">Tất cả slide</p>
                  <button type="button" className="rounded-full border border-line p-2" onClick={() => setOverview(false)} aria-label="Đóng lưới slide">
                    <X className="size-5" />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-4">
                  {slides.map((item, itemIndex) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        go(itemIndex);
                        setOverview(false);
                      }}
                      className={`rounded-2xl border px-3 py-3 text-left ${
                        itemIndex === index ? "border-gold bg-deep" : "border-line bg-card"
                      }`}
                    >
                      <span className="text-sm font-semibold text-gold">{itemIndex + 1}</span>
                      <span className="mt-1 block text-sm leading-snug text-ink">{item.title}</span>
                    </button>
                  ))}
                </div>
              </div>
            ) : null}
          </main>
          {notes ? (
            <aside className="max-h-48 shrink-0 overflow-y-auto border-t border-line bg-deep px-4 py-3 lg:max-h-none lg:w-80 lg:border-t-0 lg:border-l">
              <p className="text-sm font-semibold text-gold">Ghi chú thuyết trình</p>
              <p className="mt-2 text-base leading-relaxed text-ink">{slide.notes}</p>
            </aside>
          ) : null}
        </div>
        <footer className="flex items-center justify-between gap-2 border-t border-line px-3 py-2 pr-16 md:px-5 md:pr-24">
          <div className="flex items-center gap-2">
            <button type="button" className="rounded-full border border-line p-2" onClick={() => go(index - 1)} disabled={index === 0} aria-label="Slide trước">
              <ChevronLeft className="size-5" />
            </button>
            <p className="min-w-16 text-center text-sm font-semibold">
              {index + 1} / {total}
            </p>
            <button type="button" className="rounded-full border border-line p-2" onClick={() => go(index + 1)} disabled={index === total - 1} aria-label="Slide sau">
              <ChevronRight className="size-5" />
            </button>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              className={`rounded-full border px-3 py-2 text-sm font-semibold ${notes ? "border-gold text-gold" : "border-line"}`}
              onClick={() => setNotes((value) => !value)}
            >
              <StickyNote className="mr-1 inline size-4" />
              Ghi chú
            </button>
            <button type="button" className="rounded-full border border-line p-2" onClick={() => setOverview(true)} aria-label="Lưới slide">
              <LayoutGrid className="size-5" />
            </button>
            <button type="button" className="hidden rounded-full border border-line p-2 sm:block" onClick={fullscreen} aria-label="Toàn màn hình">
              <Maximize2 className="size-5" />
            </button>
          </div>
        </footer>
      </div>
    </DeckNav.Provider>
  );
}
