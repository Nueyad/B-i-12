import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as MapPin, c as ChevronRight, i as Maximize2, l as ChevronLeft, o as LayoutGrid, r as StickyNote, s as Compass, t as X } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CBc6PP6s.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DeckNav = (0, import_react.createContext)({
	go: () => {},
	index: 0
});
function useDeckNav() {
	return (0, import_react.useContext)(DeckNav);
}
var fill = {
	gold: "bg-gold",
	sea: "bg-sea",
	leaf: "bg-leaf",
	coral: "bg-coral"
};
function ColumnChart({ data, tone = "gold", caption }) {
	const max = Math.max(...data.map((item) => item.value), 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-2xl border border-line bg-deep p-3",
		role: "img",
		"aria-label": caption,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "mb-2 text-sm font-semibold text-ink",
			children: caption
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-44 items-end gap-3 md:h-52",
			children: data.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-full min-w-0 flex-1 flex-col justify-end",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-1 text-center text-sm font-semibold text-gold",
						children: item.display
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-4/5 items-end",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `bar-up w-full rounded-t-lg ${fill[tone]}`,
							style: {
								height: `${Math.max(8, item.value / max * 100)}%`,
								animationDelay: `${index * 90}ms`
							}
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-center text-sm text-muted",
						children: item.label
					})
				]
			}, item.label))
		})]
	});
}
function GroupedColumns({ groups, series, caption }) {
	const max = Math.max(...groups.flatMap((group) => group.values.map((item) => item.value)), 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-2xl border border-line bg-deep p-3",
		role: "img",
		"aria-label": caption,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mb-3 flex flex-wrap gap-3",
			children: series.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "inline-flex items-center gap-2 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: `size-3 rounded-sm ${fill[item.tone]}` }), item.name]
			}, item.key))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex h-52 items-end gap-2 md:h-64",
			children: groups.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-full min-w-0 flex-1 flex-col justify-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex h-4/5 items-end gap-1",
					children: group.values.map((item, index) => {
						const tone = series.find((entry) => entry.key === item.key)?.tone ?? "gold";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex h-full min-w-0 flex-1 flex-col justify-end",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-1 text-center text-sm font-semibold text-ink",
								children: item.display
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `bar-up w-full rounded-t-md ${fill[tone]}`,
								style: {
									height: `${Math.max(6, item.value / max * 100)}%`,
									animationDelay: `${index * 70}ms`
								}
							})]
						}, item.key);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-center text-sm text-muted",
					children: group.label
				})]
			}, group.label))
		})]
	});
}
function DivergingPair({ data, nameA, nameB, caption }) {
	const max = Math.max(...data.flatMap((item) => [Math.abs(item.a), Math.abs(item.b)]), 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "rounded-2xl border border-line bg-deep p-4",
		role: "img",
		"aria-label": caption,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex flex-wrap gap-4 text-sm text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-sm bg-gold" }), nameA]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "inline-flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-3 rounded-sm bg-sea" }), nameB]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Mốc 0 ở giữa · cột về bên trái là mức giảm" })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: data.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[3.5rem_1fr] items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-semibold text-muted",
					children: item.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-14",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-y-1 left-1/2 w-px bg-line" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HBar, {
							value: item.a,
							max,
							display: item.aDisplay,
							tone: "gold",
							edge: "top-1"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HBar, {
							value: item.b,
							max,
							display: item.bDisplay,
							tone: "sea",
							edge: "bottom-1"
						})
					]
				})]
			}, item.label))
		})]
	});
}
function HBar({ value, max, display, tone, edge }) {
	const negative = value < 0;
	const width = `${Math.abs(value) / max * 34}%`;
	const color = negative ? "bg-coral" : tone === "gold" ? "bg-gold" : "bg-sea";
	const grow = negative ? "bar-left" : "bar-right";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `absolute ${edge} h-5`,
		style: negative ? {
			right: "50%",
			width
		} : {
			left: "50%",
			width
		},
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `h-full rounded-md ${color} ${grow}` }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: `absolute top-0 left-full pl-1 text-sm font-semibold whitespace-nowrap ${negative ? "text-coral" : "text-ink"}`,
			children: display
		})]
	});
}
function Shell({ kicker, title, tone = "sea", source, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-full flex-col px-4 py-4 md:px-10 md:py-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `mb-3 h-1 w-14 rounded-full ${tone === "leaf" ? "bg-leaf" : tone === "gold" ? "bg-gold" : "bg-sea"}` }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold tracking-widest text-gold",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 max-w-5xl text-2xl font-bold leading-tight text-balance text-ink md:text-4xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 flex min-h-0 flex-1 flex-col gap-4",
				children
			}),
			source ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-muted",
				children: source
			}) : null
		]
	});
}
function Points({ items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "space-y-3",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex gap-3 text-base leading-snug text-ink md:text-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-2 size-2 shrink-0 rounded-full bg-gold",
				"aria-hidden": true
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: item })]
		}, item))
	});
}
function Stat({ value, unit, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-line bg-deep px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-3xl font-bold text-gold md:text-4xl",
				children: value
			}),
			unit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium text-sea",
				children: unit
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm leading-snug text-muted md:text-base",
				children: label
			})
		]
	});
}
function Remark({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rounded-2xl border border-gold/40 bg-deep px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold text-gold",
			children: "Nhận xét"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-base leading-relaxed text-ink",
			children
		})]
	});
}
function SgkFigure({ src, alt, caption }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
		className: "overflow-hidden rounded-2xl border border-line bg-paper",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt,
			className: "max-h-[46vh] w-full object-contain"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("figcaption", {
			className: "px-3 py-2 text-sm leading-snug text-paper-ink",
			children: caption
		})]
	});
}
function DataTable({ headers, rows, highlightCol }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-x-auto rounded-2xl border border-line",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-lg border-collapse text-left text-sm md:text-base",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: "bg-deep text-gold",
				children: headers.map((header) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
					className: "px-3 py-2 font-semibold whitespace-nowrap",
					children: header
				}, header))
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: rows.map((row, rowIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", {
				className: rowIndex % 2 ? "bg-deep/70" : "bg-card",
				children: row.map((cell, cellIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
					className: `px-3 py-2 whitespace-nowrap ${cellIndex === 0 ? "font-semibold text-ink" : cell.startsWith("−") ? "font-semibold text-coral" : cellIndex === highlightCol ? "font-semibold text-gold" : "text-ink"}`,
					children: cell
				}, `${row[0]}-${cellIndex}`))
			}, row[0])) })]
		})
	});
}
function Chip({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "rounded-full border border-line bg-deep px-3 py-1 text-sm font-medium text-ink md:text-base",
		children
	});
}
var countries = [
	"Việt Nam",
	"Lào",
	"Cam-pu-chia",
	"Thái Lan",
	"Mi-an-ma",
	"Ma-lai-xi-a",
	"Xin-ga-po",
	"In-đô-nê-xi-a",
	"Bru-nây",
	"Phi-líp-pin"
];
function Cover() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative flex min-h-full flex-col justify-end overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/sgk/hinh-12-2.jpg",
				alt: "",
				className: "map-zoom absolute inset-0 size-full object-cover opacity-45"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-ocean via-ocean/75 to-ocean/35" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compass, { className: "absolute top-6 right-6 size-16 text-gold/80 md:top-10 md:right-10 md:size-20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative px-5 pt-16 pb-8 md:px-12 md:pb-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold tracking-widest text-gold",
						children: "ĐỊA LÍ 11 · BÀI 12"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 max-w-4xl text-4xl font-bold leading-tight text-balance text-ink md:text-6xl",
						children: "Kinh tế khu vực Đông Nam Á"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-2xl text-base leading-relaxed text-ink md:text-xl",
						children: "Tình hình phát triển và các ngành kinh tế — nông nghiệp, lâm nghiệp, thủy sản, công nghiệp và dịch vụ."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 flex flex-wrap gap-2",
						children: countries.map((name, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "chip-in rounded-full border border-line bg-ocean/70 px-3 py-1 text-sm text-ink",
							style: { animationDelay: `${180 + index * 70}ms` },
							children: name
						}, name))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-sm text-muted",
						children: "Nội dung và số liệu theo SGK Địa lí 11, Bài 12."
					})
				]
			})
		]
	});
}
function Section({ part, title, lead, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: `flex min-h-full flex-col justify-center bg-gradient-to-br ${tone === "leaf" ? "from-leaf/25" : tone === "gold" ? "from-gold/20" : "from-sea/25"} to-ocean px-6 py-10 md:px-14`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold tracking-widest text-gold",
				children: part
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 max-w-4xl text-4xl font-bold leading-tight text-balance text-ink md:text-6xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-2xl text-lg leading-relaxed text-ink md:text-2xl",
				children: lead
			})
		]
	});
}
var questions = [
	{
		level: "Nhận biết",
		prompt: "Năm 2020, quy mô GDP của Đông Nam Á khoảng bao nhiêu và chiếm khoảng bao nhiêu phần trăm GDP thế giới?",
		answer: "Khoảng 3 083,3 tỉ USD, chiếm khoảng 3,6% GDP toàn thế giới (Bảng 12.1, Ngân hàng Thế giới, 2022)."
	},
	{
		level: "Nhận biết",
		prompt: "Nêu cây lương thực quan trọng nhất và hai nước xuất khẩu gạo hàng đầu của khu vực.",
		answer: "Lúa gạo. In-đô-nê-xi-a có sản lượng lớn nhất khu vực (54,6 triệu tấn, thứ ba thế giới năm 2020). Thái Lan và Việt Nam là hai nước xuất khẩu gạo hàng đầu."
	},
	{
		level: "Thông hiểu",
		prompt: "Vì sao tốc độ tăng GDP Đông Nam Á năm 2020 là −1,1%, trong khi năm 2019 là 4,5%?",
		answer: "Do ảnh hưởng của dịch bệnh. GDP giảm từ 3 314,1 tỉ USD (2019) xuống 3 083,3 tỉ USD (2020). Cùng năm, thế giới giảm −3,3%."
	},
	{
		level: "Thông hiểu",
		prompt: "Dựa vào Bảng 12.2, nhận xét sản lượng lúa gạo và cao su của Đông Nam Á giai đoạn 2000–2020.",
		answer: "Lúa gạo: 152,1 triệu tấn (2000) → 196,7 (2010) → 190,1 (2020): tăng rồi giảm nhẹ. Cao su tăng liên tục: 5,3 → 8,0 → 10,7 triệu tấn, chiếm phần lớn sản lượng thế giới (thế giới năm 2020: 14,0 triệu tấn)."
	},
	{
		level: "Vận dụng",
		prompt: "Giải thích vì sao điện tử – tin học trở thành ngành mũi nhọn ở một số nước, và điều đó thể hiện hướng chuyển dịch nào của nền kinh tế?",
		answer: "Ngành phát triển ở Xin-ga-po, Thái Lan, Ma-lai-xi-a, Việt Nam nhờ lao động trẻ, trình độ kĩ thuật và vốn đầu tư nước ngoài; các nước tham gia chuỗi giá trị toàn cầu. Đó là biểu hiện chuyển dịch theo hướng công nghiệp hóa, hiện đại hóa."
	}
];
function Quiz() {
	const [open, setOpen] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		kicker: "PHẦN III · CỦNG CỐ",
		title: "Câu hỏi",
		tone: "gold",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3",
			children: questions.map((item, index) => {
				const shown = open === index;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-deep px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm font-semibold text-gold",
							children: [
								"Câu ",
								index + 1,
								" · ",
								item.level
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-base leading-snug text-ink md:text-lg",
							children: item.prompt
						}),
						shown ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-base leading-relaxed text-sea",
							children: item.answer
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "mt-2 text-sm font-semibold text-gold underline-offset-2 hover:underline",
							onClick: () => setOpen(shown ? null : index),
							children: shown ? "Ẩn gợi ý" : "Hiện gợi ý"
						})
					]
				}, item.prompt);
			})
		})
	});
}
function Answers() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
		kicker: "PHẦN III · GỢI Ý",
		title: "Đáp án để thầy cô sử dụng",
		tone: "gold",
		source: "Đáp án bám số liệu và ý SGK. Không chấm máy móc từng chữ.",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3",
			children: questions.map((item, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-2xl border border-line bg-card px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm font-semibold text-gold",
					children: [
						"Câu ",
						index + 1,
						" · ",
						item.level
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-base text-ink",
					children: item.answer
				})]
			}, item.prompt))
		})
	});
}
function EndSlide() {
	const { go } = useDeckNav();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "flex min-h-full flex-col items-start justify-center px-6 py-10 md:px-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold tracking-widest text-gold",
				children: "KHÉP LẠI BÀI 12"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 max-w-4xl text-4xl font-bold leading-tight text-balance text-ink md:text-6xl",
				children: "Đông Nam Á năng động, đang chuyển dịch — và vẫn còn chênh lệch."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-5 max-w-2xl text-lg leading-relaxed text-ink md:text-xl",
				children: "Nông nghiệp nhiệt đới giữ vai trò lương thực và xuất khẩu. Công nghiệp và dịch vụ ngày càng quyết định nhịp tăng trưởng."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: () => go(0),
				className: "mt-8 rounded-full bg-gold px-5 py-3 text-base font-semibold text-paper-ink",
				children: "Về trang bìa"
			})
		]
	});
}
function Mindmap() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
		kicker: "PHẦN III · TỔNG KẾT",
		title: "Sơ đồ tư duy toàn bài",
		tone: "gold",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl border border-gold bg-deep px-4 py-3 text-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xl font-bold text-gold md:text-2xl",
					children: "Kinh tế khu vực Đông Nam Á"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted md:text-base",
					children: "Vị trí · Điều kiện tự nhiên · Tài nguyên · Lao động · Vốn đầu tư bên ngoài"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [
					{
						title: "Tình hình",
						tone: "border-sea",
						lines: [
							"GDP 2020: 3 083,3 tỉ USD, khoảng 3,6% thế giới",
							"Tăng nhanh; năm 2020 giảm do dịch bệnh",
							"Chuyển dịch theo hướng công nghiệp hóa, hiện đại hóa"
						]
					},
					{
						title: "Nông – lâm – thủy sản",
						tone: "border-leaf",
						lines: [
							"Lúa gạo, cây công nghiệp, cây ăn quả, chăn nuôi",
							"Gỗ tròn năm 2020: 302,0 triệu m³",
							"Thủy sản khoảng 25% sản lượng toàn cầu (2020)"
						]
					},
					{
						title: "Công nghiệp",
						tone: "border-gold",
						lines: [
							"Điện tử – tin học là ngành mũi nhọn",
							"Chế biến thực phẩm, hàng tiêu dùng, khoáng sản",
							"Trung tâm: Băng Cốc, Gia-các-ta, TP. Hồ Chí Minh"
						]
					},
					{
						title: "Dịch vụ",
						tone: "border-sea",
						lines: [
							"Thương mại xuất siêu; đối tác lớn: Trung Quốc, Hoa Kỳ, Hàn Quốc",
							"Đường bộ, đường sắt, đường biển, hàng không",
							"Tài chính và du lịch ngày càng quan trọng"
						]
					}
				].map((branch) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: `rounded-2xl border border-line border-t-4 ${branch.tone} bg-card px-4 py-3`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-bold text-ink",
						children: branch.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 space-y-1",
						children: branch.lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "text-sm leading-snug text-ink md:text-base",
							children: line
						}, line))
					})]
				}, branch.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Remark, { children: "Thành tựu gắn với việc tận dụng lợi thế riêng, nhưng trình độ phát triển giữa các quốc gia còn chênh lệch lớn và khu vực đứng trước nhiều thách thức của toàn cầu hóa." })
		]
	});
}
var slides = [
	{
		id: "cover",
		title: "Trang bìa",
		fx: "zoom",
		notes: "Mở bài bằng bản đồ khu vực. Nhấn mạnh trọng tâm là kinh tế Đông Nam Á, không phải bài giới thiệu chung. Mời học sinh nhìn các quốc gia hiện lần lượt rồi chuyển sang câu hỏi định hướng.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {})
	},
	{
		id: "question",
		title: "Câu hỏi định hướng",
		fx: "fade",
		notes: "Đọc nguyên câu dẫn trong SGK. Dừng lại ở hai câu hỏi: kinh tế phát triển ra sao, và các ngành có đặc điểm gì. Chưa trả lời hết — hẹn phần tổng kết.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "MỞ BÀI",
			title: "Kinh tế Đông Nam Á đang đổi thay ra sao?",
			tone: "sea",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
				className: "rounded-2xl border border-line bg-deep px-5 py-4 text-lg leading-relaxed text-ink md:text-2xl",
				children: "Những năm gần đây, kinh tế – xã hội khu vực Đông Nam Á có nhiều chuyển biến tích cực: vai trò và vị thế của khu vực ngày càng được nâng cao. Kinh tế khu vực Đông Nam Á phát triển ra sao? Các ngành kinh tế có đặc điểm gì nổi bật?"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "3 phần",
						label: "Tình hình phát triển, các ngành kinh tế, rồi tổng kết."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "SGK",
						label: "Giữ nguyên thuật ngữ, địa danh, năm và đơn vị trong sách."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "Nhận xét",
						label: "Phần phân tích thêm luôn được ghi rõ, không trộn với số liệu SGK."
					})
				]
			})]
		})
	},
	{
		id: "roadmap",
		title: "Lộ trình bài học",
		fx: "rise",
		notes: "Chỉ ra ba chặng để học sinh biết bài dài nhưng có mạch. Nhắc quy ước: ý không gắn nhãn là của SGK; ô vàng “Nhận xét” là phân tích để hiểu bảng số liệu.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "ĐỊNH HƯỚNG",
			title: "Ba chặng của bài học",
			tone: "sea",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-3",
				children: [
					[
						"I",
						"Tình hình phát triển",
						"Quy mô GDP, tốc độ tăng, chuyển dịch cơ cấu và các yếu tố thúc đẩy."
					],
					[
						"II",
						"Các ngành kinh tế",
						"Nông – lâm – thủy sản, công nghiệp, rồi dịch vụ: thương mại, giao thông, tài chính, du lịch."
					],
					[
						"III",
						"Tổng kết",
						"Sơ đồ tư duy, câu hỏi nhận biết – thông hiểu – vận dụng và gợi ý đáp án."
					]
				].map(([index, name, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-card px-4 py-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-3xl font-bold text-gold",
							children: index
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 text-xl font-bold text-ink",
							children: name
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-base leading-relaxed text-muted",
							children: text
						})
					]
				}, index))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Remark, { children: "Khi thuyết trình, bấm phím mũi tên hoặc phím cách để sang slide. Phím N mở ghi chú. Phím G mở lưới slide." })]
		})
	},
	{
		id: "part-1",
		title: "Phần I",
		fx: "wipe",
		notes: "Chuyển phần. Một câu dẫn: trước khi đi vào từng ngành, xem khu vực lớn lên thế nào và vì sao năm 2020 bị hẫng.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
			part: "PHẦN I",
			title: "Tình hình phát triển kinh tế",
			lead: "Quy mô GDP tăng nhanh trong hai thập niên, cơ cấu chuyển dịch — rồi dịch bệnh năm 2020 kéo tốc độ tăng trưởng xuống.",
			tone: "sea"
		})
	},
	{
		id: "gdp-hero",
		title: "Quy mô và vị thế năm 2020",
		fx: "drop",
		notes: "Đọc số trung tâm trước: khoảng 3 083 tỉ USD, bằng 3,6% GDP thế giới. Nhấn “khoảng” đúng lời SGK ở đoạn mở, còn số chi tiết 3 083,3 nằm ở Bảng 12.1. Nêu ngay Xin-ga-po, Thái Lan, Việt Nam là ví dụ các nước tăng trưởng cao.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "I · TÌNH HÌNH",
			title: "Một nền kinh tế năng động bậc nhất thế giới",
			tone: "sea",
			source: "SGK Địa lí 11, Bài 12. Số liệu chi tiết: Bảng 12.1 — Ngân hàng Thế giới, 2022.",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "3 083,3",
						unit: "tỉ USD",
						label: "Quy mô GDP Đông Nam Á năm 2020."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "3,6%",
						unit: "GDP thế giới",
						label: "Vị thế của khu vực trong nền kinh tế toàn cầu."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "4,5%",
						unit: "năm 2019",
						label: "Tốc độ tăng GDP trước khi dịch bệnh kéo năm 2020 đi xuống."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
				"Trong những năm qua, quy mô GDP các nước Đông Nam Á tăng khá nhanh.",
				"Năm 2020, do ảnh hưởng của dịch bệnh, tốc độ tăng GDP giảm đáng kể.",
				"Những quốc gia có tốc độ tăng trưởng cao được SGK nêu: Xin-ga-po, Thái Lan, Việt Nam,…"
			] })]
		})
	},
	{
		id: "table-121",
		title: "Bảng 12.1 — quy mô GDP",
		fx: "rise",
		notes: "Cho học sinh đọc bảng theo hàng Đông Nam Á trước, hàng thế giới sau. Cột biểu đồ chỉ vẽ Đông Nam Á để không bị lệch tỉ lệ với thế giới. Nhận xét 5,4 lần là phép tính từ 614,7 lên 3 314,1, cần nói rõ là nhận xét, không phải câu in sẵn trong sách.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "BẢNG 12.1",
			title: "Quy mô GDP theo giá hiện hành",
			tone: "gold",
			source: "Đơn vị: tỉ USD. Nguồn: Ngân hàng Thế giới, 2022.",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					headers: [
						"Năm",
						"2000",
						"2010",
						"2019",
						"2020"
					],
					highlightCol: 4,
					rows: [[
						"Đông Nam Á",
						"614,7",
						"2 017,3",
						"3 314,1",
						"3 083,3"
					], [
						"Thế giới",
						"33 830,9",
						"66 596,0",
						"87 652,9",
						"84 906,8"
					]]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnChart, {
					caption: "GDP Đông Nam Á, tỉ USD",
					data: [
						{
							label: "2000",
							value: 614.7,
							display: "614,7"
						},
						{
							label: "2010",
							value: 2017.3,
							display: "2 017,3"
						},
						{
							label: "2019",
							value: 3314.1,
							display: "3 314,1"
						},
						{
							label: "2020",
							value: 3083.3,
							display: "3 083,3"
						}
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Remark, { children: "Từ năm 2000 đến năm 2019, GDP Đông Nam Á tăng từ 614,7 lên 3 314,1 tỉ USD — khoảng 5,4 lần. Năm 2020 quy mô giảm so với năm 2019. GDP thế giới cũng giảm: 87 652,9 xuống 84 906,8 tỉ USD." })]
		})
	},
	{
		id: "growth",
		title: "Tốc độ tăng GDP",
		fx: "fade",
		notes: "Cột vàng là Đông Nam Á, cột xanh là thế giới. Học sinh thấy hầu hết các mốc khu vực cao hơn thế giới, và cả hai cùng âm năm 2020. Đông Nam Á −1,1% vẫn giảm ít hơn thế giới −3,3%. Đó là nhận xét từ bảng.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "BẢNG 12.1",
			title: "Tốc độ tăng GDP của khu vực và thế giới",
			tone: "gold",
			source: "Đơn vị: %. Nguồn: Ngân hàng Thế giới, 2022. Cột dưới mốc 0 là mức giảm.",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					headers: [
						"Tốc độ tăng GDP (%)",
						"2000",
						"2010",
						"2019",
						"2020"
					],
					rows: [[
						"Đông Nam Á",
						"7,0",
						"7,8",
						"4,5",
						"−1,1"
					], [
						"Thế giới",
						"4,5",
						"4,5",
						"2,6",
						"−3,3"
					]]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DivergingPair, {
					nameA: "Đông Nam Á",
					nameB: "Thế giới",
					caption: "Tốc độ tăng GDP, phần trăm",
					data: [
						{
							label: "2000",
							a: 7,
							b: 4.5,
							aDisplay: "7,0",
							bDisplay: "4,5"
						},
						{
							label: "2010",
							a: 7.8,
							b: 4.5,
							aDisplay: "7,8",
							bDisplay: "4,5"
						},
						{
							label: "2019",
							a: 4.5,
							b: 2.6,
							aDisplay: "4,5",
							bDisplay: "2,6"
						},
						{
							label: "2020",
							a: -1.1,
							b: -3.3,
							aDisplay: "−1,1",
							bDisplay: "−3,3"
						}
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Remark, { children: "Ở các mốc 2000, 2010 và 2019, Đông Nam Á tăng nhanh hơn mức chung của thế giới. Năm 2020 cả hai đều âm; khu vực giảm ít hơn thế giới." })
			]
		})
	},
	{
		id: "covid",
		title: "Năm 2020 và dịch bệnh",
		fx: "wipe",
		notes: "Đừng biến slide này thành bản tin dịch. Chỉ gắn đúng ý SGK: dịch bệnh làm tốc độ tăng GDP giảm đáng kể, và chỉ vào hai cặp số 4,5% xuống −1,1% và 3 314,1 xuống 3 083,3.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "I · NĂM 2020",
			title: "Dịch bệnh kéo cả quy mô lẫn tốc độ tăng",
			tone: "sea",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					value: "4,5% → −1,1%",
					label: "Tốc độ tăng GDP Đông Nam Á, từ năm 2019 sang năm 2020."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					value: "3 314,1 → 3 083,3",
					unit: "tỉ USD",
					label: "Quy mô GDP khu vực giảm trong năm 2020."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
				"SGK nêu rõ: năm 2020, do ảnh hưởng của dịch bệnh nên tốc độ tăng GDP giảm đáng kể.",
				"Thế giới cùng lúc giảm sâu hơn: tốc độ tăng GDP −3,3%, quy mô từ 87 652,9 xuống 84 906,8 tỉ USD.",
				"Một năm suy giảm không xóa thành tựu hai thập niên tăng trưởng trước đó."
			] })]
		})
	},
	{
		id: "shift",
		title: "Chuyển dịch cơ cấu và nguyên nhân",
		fx: "rise",
		notes: "Hai ý SGK: công nghiệp hóa, hiện đại hóa; một số nước chú trọng kinh tế tri thức, nghiên cứu và phát triển. Sau đó đọc năm lợi thế. Chênh lệch để sang slide sau, tránh nhồi.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "I · CƠ CẤU",
			title: "Công nghiệp hóa, hiện đại hóa — và vì sao làm được",
			tone: "sea",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
				"Cơ cấu kinh tế của hầu hết các nước đang chuyển dịch theo hướng công nghiệp hóa, hiện đại hóa.",
				"Một số quốc gia chú trọng nền kinh tế tri thức, đẩy mạnh nghiên cứu và phát triển.",
				"Thành tựu có được nhờ các nước tận dụng vị trí địa lí, điều kiện tự nhiên và tài nguyên thiên nhiên.",
				"Thêm lực lượng lao động cùng khả năng thu hút nguồn đầu tư từ bên ngoài."
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"Vị trí địa lí",
					"Điều kiện tự nhiên",
					"Tài nguyên",
					"Lao động",
					"Đầu tư bên ngoài"
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: item }, item))
			})]
		})
	},
	{
		id: "fig-121",
		title: "Hình 12.1 — cơ cấu GDP",
		fx: "zoom",
		notes: "Chiếu đúng biểu đồ SGK. Với Việt Nam, đọc xu hướng nông nghiệp giảm 19,3% xuống 12,7%, công nghiệp năm 2020 là 36,7%, dịch vụ quanh 40–42%. Với In-đô-nê-xi-a, công nghiệp giảm 44,1% xuống 38,3%, dịch vụ lên 44,4%. Nhắc nhóm thuế có trên biểu đồ nhưng chữ số quá nhỏ, không chép số nếu không chắc. Ảnh cột 2005 của In-đô-nê-xi-a cũng khó đọc nhóm nông nghiệp.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
			kicker: "HÌNH 12.1",
			title: "Cơ cấu GDP In-đô-nê-xi-a và Việt Nam, 2005–2020",
			tone: "gold",
			source: "Nguồn biểu đồ: Ngân hàng Thế giới, 2022. Ảnh chụp từ SGK để đối chiếu.",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SgkFigure, {
					src: "/sgk/hinh-12-1.jpg",
					alt: "Biểu đồ cơ cấu GDP của In-đô-nê-xi-a và Việt Nam giai đoạn 2005–2020",
					caption: "Hình 12.1. Bốn nhóm: nông nghiệp, lâm nghiệp và thủy sản; công nghiệp và xây dựng; dịch vụ; thuế sản phẩm trừ trợ cấp sản phẩm."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
						headers: [
							"Việt Nam (%)",
							"2005",
							"2010",
							"2015",
							"2020"
						],
						rows: [
							[
								"Nông nghiệp, lâm nghiệp, thủy sản",
								"19,3",
								"15,4",
								"14,5",
								"12,7"
							],
							[
								"Công nghiệp và xây dựng",
								"38,1",
								"33,0",
								"34,3",
								"36,7"
							],
							[
								"Dịch vụ",
								"42,6",
								"40,6",
								"42,2",
								"41,8"
							]
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Remark, { children: "Việt Nam: nông nghiệp giảm từ 19,3% (2005) xuống 12,7% (2020); công nghiệp và xây dựng năm 2020 là 36,7%; dịch vụ giữ quanh 40–42%. In-đô-nê-xi-a: công nghiệp giảm từ 44,1% (2005) xuống 38,3% (2020), dịch vụ lên 44,4% (2020). Nhóm thuế có trên hình nhưng số in rất nhỏ — không chép khi chưa đối chiếu sách." })]
				})]
			})
		})
	},
	{
		id: "gaps",
		title: "Chênh lệch và thách thức",
		fx: "fade",
		notes: "Chốt phần I bằng đúng câu SGK: vẫn chênh lệch lớn về trình độ phát triển và nhiều thách thức trong toàn cầu hóa. Có thể hỏi: vì sao cùng khu vực mà Xin-ga-po khác Lào? Không cần trả lời hết.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "I · THÁCH THỨC",
			title: "Cùng một khu vực, không cùng một nhịp",
			tone: "sea",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
				"Giữa các quốc gia vẫn có sự chênh lệch lớn về trình độ phát triển kinh tế.",
				"Khu vực đang phải đối mặt với nhiều thách thức trong bối cảnh toàn cầu hóa.",
				"Lợi thế về vị trí, tài nguyên, lao động và vốn ngoài không tự động san đều cho mọi nước."
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Remark, { children: "Phần II sẽ cho thấy sự chênh lệch ấy ngay trong cách từng ngành phân bố: nơi nào trồng lúa, nơi nào làm điện tử, nơi nào thành cảng hay trung tâm tài chính." })]
		})
	},
	{
		id: "part-2",
		title: "Phần II",
		fx: "wipe",
		notes: "Chuyển màu sang nhóm ngành. Nhắc học sinh: ba nhóm sẽ đi theo thứ tự SGK, mỗi nhóm có vai trò, đặc điểm và ví dụ nước.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
			part: "PHẦN II",
			title: "Các ngành kinh tế",
			lead: "Phần lớn các nước đang chuyển dịch cơ cấu, khai thác tốt hơn tiềm năng của từng ngành và nâng hiệu quả kinh tế.",
			tone: "leaf"
		})
	},
	{
		id: "agri-role",
		title: "Vai trò nông – lâm – thủy sản",
		fx: "rise",
		notes: "Ý then chốt: tỉ trọng trong GDP giảm nhưng vai trò không mất. Nhắc an ninh lương thực, việc làm và ngoại tệ. Một số nước đẩy nông nghiệp sản xuất hàng hóa.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
			kicker: "1 · NÔNG NGHIỆP, LÂM NGHIỆP VÀ THỦY SẢN",
			title: "Nông nghiệp nhiệt đới, sản phẩm đa dạng",
			tone: "leaf",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
				"Đông Nam Á có nền nông nghiệp nhiệt đới với cơ cấu sản phẩm đa dạng.",
				"Tỉ trọng ngành trong cơ cấu GDP ngày càng giảm, nhưng vai trò vẫn quan trọng.",
				"Ngành vừa bảo đảm lương thực, thực phẩm, vừa tạo hàng xuất khẩu và nguồn ngoại tệ.",
				"Trồng trọt là ngành chính ở phần lớn các nước. Cây trồng chính: lúa gạo, cây công nghiệp và cây ăn quả.",
				"Một số quốc gia đang đẩy mạnh nông nghiệp sản xuất hàng hóa quy mô lớn."
			] })
		})
	},
	{
		id: "rice",
		title: "Lúa gạo",
		fx: "fade",
		notes: "Đây là cây lương thực truyền thống, quan trọng nhất. Nhấn sản lượng tăng giúp giải quyết lương thực và còn xuất khẩu. Số 54,6 triệu tấn và thứ ba thế giới là của In-đô-nê-xi-a năm 2020. Thái Lan và Việt Nam là hai nước xuất khẩu hàng đầu — không nhầm với nước có sản lượng lớn nhất.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "1 · TRỒNG TRỌT",
			title: "Lúa gạo: lương thực và mặt hàng xuất khẩu",
			tone: "leaf",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "54,6",
						unit: "triệu tấn",
						label: "Sản lượng lúa của In-đô-nê-xi-a năm 2020 — lớn nhất khu vực."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "Thứ 3",
						unit: "thế giới, 2020",
						label: "Vị trí của In-đô-nê-xi-a về sản lượng lúa gạo."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "2 nước",
						label: "Thái Lan và Việt Nam — xuất khẩu gạo hàng đầu thế giới."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: ["Lúa gạo là cây lương thực truyền thống và quan trọng nhất của khu vực.", "Sản lượng lúa ngày càng tăng nên các nước đã cơ bản giải quyết nhu cầu lương thực và có xuất khẩu."] })]
		})
	},
	{
		id: "crops",
		title: "Cây công nghiệp",
		fx: "rise",
		notes: "Bốn cây đứng hàng đầu thế giới: cao su, cọ dầu, cà phê, hồ tiêu. Gắn đúng nước: cao su bốn nước; cọ dầu chỉ In-đô-nê-xi-a và Ma-lai-xi-a; cà phê và hồ tiêu thêm Việt Nam, Thái Lan.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "1 · CÂY CÔNG NGHIỆP",
			title: "Đứng hàng đầu thế giới về cao su, cọ dầu, cà phê, hồ tiêu",
			tone: "leaf",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [
					["Cao su", "Ma-lai-xi-a, In-đô-nê-xi-a, Thái Lan, Việt Nam"],
					["Cọ dầu", "In-đô-nê-xi-a và Ma-lai-xi-a"],
					["Cà phê", "Việt Nam, In-đô-nê-xi-a, Ma-lai-xi-a, Thái Lan"],
					["Hồ tiêu", "Việt Nam, In-đô-nê-xi-a, Ma-lai-xi-a, Thái Lan"]
				].map(([name, where]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-card px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-xl font-bold text-leaf",
						children: name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-base leading-snug text-ink",
						children: where
					})]
				}, name))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-base text-muted",
				children: "Các cây này có giá trị xuất khẩu cao."
			})]
		})
	},
	{
		id: "fruit",
		title: "Cây ăn quả và chăn nuôi",
		fx: "fade",
		notes: "Ăn quả: xoài, chôm chôm, sầu riêng, dừa, chuối — hầu hết các nước, là hàng xuất khẩu đáng kể. Chăn nuôi được chú trọng vì đời sống nâng lên và hiệu quả kinh tế. Trâu bò, lợn, gia cầm gắn đúng nhóm nước trong SGK.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "1 · ĂN QUẢ VÀ CHĂN NUÔI",
			title: "Vừa đa dạng trong khu vực, vừa có hàng xuất khẩu",
			tone: "leaf",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-card px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-bold text-ink",
						children: "Cây ăn quả"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-base leading-relaxed text-ink",
						children: "Xoài, chôm chôm, sầu riêng, dừa, chuối… được trồng ở hầu hết các nước. Đây là mặt hàng xuất khẩu mang lại nguồn thu ngoại tệ đáng kể."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-card px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-bold text-ink",
						children: "Chăn nuôi"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-2 space-y-2 text-base leading-snug text-ink",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Trâu, bò: Mi-an-ma, In-đô-nê-xi-a, Thái Lan, Việt Nam." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Lợn: Việt Nam, Phi-líp-pin, Thái Lan, In-đô-nê-xi-a." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Gia cầm: phổ biến ở hầu hết các nước." })
						]
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Remark, { children: "SGK gắn sự chú trọng chăn nuôi với chất lượng cuộc sống được nâng lên và hiệu quả kinh tế cao." })]
		})
	},
	{
		id: "forest",
		title: "Lâm nghiệp",
		fx: "rise",
		notes: "Ngành quan trọng với In-đô-nê-xi-a, Thái Lan, Mi-an-ma, Việt Nam. Hai số gỗ tròn: 299,1 triệu m³ năm 2000 và 302,0 triệu m³ năm 2020, khoảng 7,7% thế giới. Nhấn cả khai thác lẫn trồng rừng, khoanh nuôi, vườn quốc gia, khu bảo tồn — không chỉ có chặt gỗ.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "1 · LÂM NGHIỆP",
			title: "Khai thác gỗ đi cùng bảo vệ rừng",
			tone: "leaf",
			source: "Sản lượng gỗ tròn theo SGK Địa lí 11, Bài 12.",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "299,1",
						unit: "triệu m³",
						label: "Gỗ tròn khai thác năm 2000."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "302,0",
						unit: "triệu m³",
						label: "Gỗ tròn khai thác năm 2020."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "7,7%",
						unit: "thế giới",
						label: "Tỉ lệ gỗ tròn của khu vực năm 2020."
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
				"Lâm nghiệp quan trọng với In-đô-nê-xi-a, Thái Lan, Mi-an-ma và Việt Nam.",
				"Các nước tăng cường trồng rừng, khoanh nuôi rừng tự nhiên.",
				"Đồng thời thành lập vườn quốc gia và khu bảo tồn thiên nhiên."
			] })]
		})
	},
	{
		id: "fish",
		title: "Thủy sản",
		fx: "fade",
		notes: "Điều kiện thuận lợi, vừa khai thác vừa nuôi. Năm 2020 đóng góp khoảng 25% sản lượng thủy sản toàn cầu. Nước sản xuất lớn: In-đô-nê-xi-a, Việt Nam, Phi-líp-pin. Thách thức là nguồn lợi suy giảm. Thái Lan, Việt Nam, Phi-líp-pin chú trọng nuôi trồng. Sản phẩm là mặt hàng xuất khẩu chủ lực.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "1 · THỦY SẢN",
			title: "Khoảng một phần tư thủy sản toàn cầu",
			tone: "leaf",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					value: "~25%",
					unit: "năm 2020",
					label: "Đông Nam Á đóng góp vào tổng sản lượng thủy sản toàn cầu."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					value: "3 nước lớn",
					label: "In-đô-nê-xi-a, Việt Nam và Phi-líp-pin — các nước sản xuất thủy sản lớn trong khu vực."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
				"Khu vực có nhiều điều kiện thuận lợi; các nước đã đầu tư vốn, công nghệ, kĩ thuật cho đánh bắt và nuôi trồng.",
				"Sản phẩm thủy sản là mặt hàng xuất khẩu chủ lực: tôm, cá ngừ đại dương, cá da trơn,…",
				"Khai thác đang đi theo hướng công nghiệp hóa, hiện đại hóa và bền vững vì nguồn lợi suy giảm, ảnh hưởng đời sống của hàng chục triệu người.",
				"Thái Lan, Việt Nam, Phi-líp-pin chú trọng nuôi thủy sản để đáp ứng nhu cầu và bảo vệ nguồn lợi tự nhiên."
			] })]
		})
	},
	{
		id: "map-122",
		title: "Hình 12.2 — bản đồ nông lâm thủy sản",
		fx: "zoom",
		notes: "Dừng ở bản đồ. Hướng dẫn đọc chú giải: lúa gạo, vùng trồng trọt, rừng, cây công nghiệp, chăn nuôi, khai thác thủy sản. Không yêu cầu nhớ từng chấm. Câu hỏi SGK: trình bày sự phát triển và phân bố dựa trên mục 1 và hình này.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
			kicker: "HÌNH 12.2",
			title: "Phân bố nông nghiệp, lâm nghiệp và thủy sản năm 2020",
			tone: "leaf",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SgkFigure, {
				src: "/sgk/hinh-12-2.jpg",
				alt: "Bản đồ phân bố nông nghiệp, lâm nghiệp và thủy sản khu vực Đông Nam Á năm 2020",
				caption: "Hình 12.2. Bản đồ SGK — đối chiếu chú giải lúa gạo, cây công nghiệp, chăn nuôi, rừng và khai thác thủy sản. Ảnh chụp từ sách."
			})
		})
	},
	{
		id: "table-122",
		title: "Bảng 12.2 — sản lượng",
		fx: "rise",
		notes: "Đây là biểu đồ gợi ý cho bài tập vẽ biểu đồ từ Bảng 12.2. Ba chỉ tiêu tách ba biểu đồ vì đơn vị và quy mô khác nhau. Nhận xét lúa khoảng 1/4 thế giới và cao su khoảng 3/4 là phép tính từ bảng, phải nói là nhận xét. Đàn lợn tăng rồi giảm.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "BẢNG 12.2",
			title: "Lúa gạo, cao su và đàn lợn, 2000–2020",
			tone: "leaf",
			source: "Nguồn: Tổ chức Lương thực và Nông nghiệp Liên hợp quốc, 2022. Ba biểu đồ ở slide sau.",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
				headers: [
					"Chỉ tiêu",
					"2000",
					"2010",
					"2020"
				],
				rows: [
					[
						"Lúa gạo Đông Nam Á (triệu tấn)",
						"152,1",
						"196,7",
						"190,1"
					],
					[
						"Lúa gạo thế giới (triệu tấn)",
						"598,7",
						"694,5",
						"769,2"
					],
					[
						"Cao su Đông Nam Á (triệu tấn)",
						"5,3",
						"8,0",
						"10,7"
					],
					[
						"Cao su thế giới (triệu tấn)",
						"7,1",
						"10,8",
						"14,0"
					],
					[
						"Đàn lợn Đông Nam Á (triệu con)",
						"52,4",
						"72,4",
						"65,6"
					],
					[
						"Đàn lợn thế giới (triệu con)",
						"898,7",
						"971,1",
						"937,5"
					]
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Remark, { children: "Tính từ bảng: năm 2020 lúa gạo khu vực bằng khoảng 1/4 sản lượng thế giới (190,1 / 769,2). Cao su khu vực bằng khoảng 3/4 thế giới (10,7 / 14,0). Đàn lợn tăng mạnh tới năm 2010 rồi giảm vào năm 2020." })]
		})
	},
	{
		id: "chart-122",
		title: "Biểu đồ Bảng 12.2",
		fx: "fade",
		notes: "Ba biểu đồ chỉ vẽ Đông Nam Á, mỗi biểu đồ một thang đo riêng — vì lúa, cao su và đàn lợn khác đơn vị, khác quy mô. Thế giới nằm ở bảng slide trước để đối chiếu. Đây là gợi ý cho bài tập vẽ biểu đồ từ Bảng 12.2.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "BẢNG 12.2 · BIỂU ĐỒ",
			title: "Đông Nam Á qua ba mốc 2000 – 2010 – 2020",
			tone: "leaf",
			source: "Số liệu Bảng 12.2. Mỗi cột một thang đo riêng.",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 lg:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnChart, {
						tone: "gold",
						caption: "Lúa gạo — triệu tấn",
						data: [
							{
								label: "2000",
								value: 152.1,
								display: "152,1"
							},
							{
								label: "2010",
								value: 196.7,
								display: "196,7"
							},
							{
								label: "2020",
								value: 190.1,
								display: "190,1"
							}
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnChart, {
						tone: "leaf",
						caption: "Cao su — triệu tấn",
						data: [
							{
								label: "2000",
								value: 5.3,
								display: "5,3"
							},
							{
								label: "2010",
								value: 8,
								display: "8,0"
							},
							{
								label: "2020",
								value: 10.7,
								display: "10,7"
							}
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ColumnChart, {
						tone: "coral",
						caption: "Đàn lợn — triệu con",
						data: [
							{
								label: "2000",
								value: 52.4,
								display: "52,4"
							},
							{
								label: "2010",
								value: 72.4,
								display: "72,4"
							},
							{
								label: "2020",
								value: 65.6,
								display: "65,6"
							}
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: "Vàng: lúa gạo (triệu tấn)" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: "Xanh lá: cao su (triệu tấn)" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: "Cam: đàn lợn (triệu con)" })
				]
			})]
		})
	},
	{
		id: "industry-role",
		title: "Vai trò công nghiệp",
		fx: "wipe",
		notes: "Chuyển sắc từ xanh lá sang vàng – xanh biển để sang công nghiệp. Vai trò: chuyển dịch cơ cấu, việc làm, xuất khẩu. Bốn hướng ngành và ba trung tâm lớn.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
			kicker: "2 · CÔNG NGHIỆP",
			title: "Đòn bẩy của công nghiệp hóa",
			tone: "gold",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
				"Công nghiệp thúc đẩy chuyển dịch cơ cấu theo hướng công nghiệp hóa, hiện đại hóa.",
				"Ngành tạo nhiều việc làm và tăng nguồn thu ngoại tệ từ xuất khẩu.",
				"Các ngành quan trọng: điện tử – tin học, chế biến thực phẩm, sản xuất hàng tiêu dùng và khai thác khoáng sản.",
				"Một số trung tâm công nghiệp lớn: Băng Cốc (Thái Lan), Gia-các-ta (In-đô-nê-xi-a), Thành phố Hồ Chí Minh (Việt Nam)."
			] })
		})
	},
	{
		id: "electronics",
		title: "Điện tử – tin học",
		fx: "rise",
		notes: "Ngành mũi nhọn của Xin-ga-po, Thái Lan, Ma-lai-xi-a, Việt Nam. Ba lợi thế: lao động trẻ, trình độ kĩ thuật, vốn FDI. Kết luận SGK: đang tham gia chuỗi giá trị toàn cầu.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "2 · ĐIỆN TỬ – TIN HỌC",
			title: "Ngành mũi nhọn trong chuỗi giá trị toàn cầu",
			tone: "gold",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"Xin-ga-po",
					"Thái Lan",
					"Ma-lai-xi-a",
					"Việt Nam"
				].map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: name }, name))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
				"Công nghiệp điện tử – tin học đang trở thành ngành mũi nhọn của nhiều nước trong khu vực.",
				"Ngành dựa trên lao động trẻ, có trình độ kĩ thuật và thu hút đầu tư nước ngoài.",
				"Hiện nay các nước trong khu vực đang tham gia vào chuỗi giá trị toàn cầu trong lĩnh vực này."
			] })]
		})
	},
	{
		id: "food-mining",
		title: "Chế biến, hàng tiêu dùng và khoáng sản",
		fx: "fade",
		notes: "Chế biến thực phẩm và hàng tiêu dùng dựa vào nguyên liệu nhiệt đới, thị trường lớn, lao động dồi dào; phân bố rộng, nhất là các nước đông dân. Thiếc hơn một nửa sản lượng thế giới. Dầu khí nêu đúng bốn nước, Bru-nây có trong nhóm này.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
			kicker: "2 · CHẾ BIẾN VÀ KHOÁNG SẢN",
			title: "Từ nông sản nhiệt đới đến thiếc, dầu mỏ, khí",
			tone: "gold",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-card px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-bold text-ink",
						children: "Chế biến thực phẩm và hàng tiêu dùng"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-base leading-relaxed text-ink",
						children: "Dựa trên sản phẩm nông nghiệp nhiệt đới, thị trường tiêu thụ lớn và lao động dồi dào. Phân bố ở tất cả các nước, nhất là các nước đông dân: In-đô-nê-xi-a, Thái Lan, Việt Nam, Phi-líp-pin."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-card px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-bold text-ink",
						children: "Khai thác khoáng sản"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-base leading-relaxed text-ink",
						children: "Khai thác thiếc chiếm hơn một nửa sản lượng thế giới: Ma-lai-xi-a, In-đô-nê-xi-a, Mi-an-ma, Thái Lan. Dầu mỏ và khí tự nhiên phát triển mạnh ở Bru-nây, Ma-lai-xi-a, In-đô-nê-xi-a, Việt Nam."
					})]
				})]
			})
		})
	},
	{
		id: "map-123",
		title: "Hình 12.3 — bản đồ công nghiệp",
		fx: "zoom",
		notes: "Chiếu bản đồ gốc. Đọc chú giải cùng học sinh: trung tâm công nghiệp, dầu mỏ, khí, thiếc, điện tử – tin học, cảng, sân bay. Câu hỏi SGK yêu cầu trình bày và giải thích sự phát triển ngành công nghiệp từ mục 2 và hình này.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
			kicker: "HÌNH 12.3",
			title: "Phân bố công nghiệp Đông Nam Á năm 2020",
			tone: "gold",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SgkFigure, {
				src: "/sgk/hinh-12-3.jpg",
				alt: "Bản đồ phân bố công nghiệp khu vực Đông Nam Á năm 2020",
				caption: "Hình 12.3. Bản đồ SGK. Chú giải gồm trung tâm công nghiệp, khoáng sản, điện tử – tin học, cảng biển và sân bay. Ảnh chụp từ sách."
			})
		})
	},
	{
		id: "fig-124",
		title: "Hình 12.4 — điện tử ở Việt Nam",
		fx: "fade",
		notes: "Ảnh minh họa đúng hình SGK: dây chuyền sản xuất điện tử tại Việt Nam. Nối lại ba lợi thế vừa nêu — lao động trẻ, kĩ thuật, vốn nước ngoài — chứ không mô tả máy móc ngoài sách.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
			kicker: "HÌNH 12.4",
			title: "Sản xuất sản phẩm điện tử ở Việt Nam",
			tone: "gold",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-center gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SgkFigure, {
					src: "/sgk/hinh-12-4.jpg",
					alt: "Công nhân trên dây chuyền sản xuất sản phẩm điện tử ở Việt Nam",
					caption: "Hình 12.4. Sản xuất sản phẩm điện tử ở Việt Nam. Ảnh trong SGK."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
					"Việt Nam nằm trong nhóm nước mà điện tử – tin học đang trở thành ngành mũi nhọn.",
					"Hình cho thấy lao động trực tiếp trên dây chuyền — đúng lợi thế lao động trẻ, có kĩ thuật.",
					"Ngành gắn với vốn đầu tư nước ngoài và chuỗi giá trị toàn cầu, không chỉ tiêu thụ trong nước."
				] })]
			})
		})
	},
	{
		id: "services",
		title: "Vai trò dịch vụ",
		fx: "wipe",
		notes: "Mở nhóm dịch vụ: vai trò ngày càng quan trọng, thể hiện ở tỉ trọng lao động và giá trị trong GDP đều tăng. Bốn phân ngành sẽ đi lần lượt: thương mại, giao thông, tài chính, du lịch.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
			part: "3 · DỊCH VỤ",
			title: "Tỉ trọng lao động và giá trị trong GDP đều tăng",
			lead: "Các nước chú ý phát triển dịch vụ. Bốn hướng cần nhớ: thương mại, giao thông vận tải, tài chính – ngân hàng và du lịch.",
			tone: "sea"
		})
	},
	{
		id: "trade",
		title: "Thương mại",
		fx: "rise",
		notes: "Nội thương: siêu thị, trung tâm thương mại, thương mại điện tử. Bốn nước nội thương mạnh. Em có biết: nội khối ASEAN 500 lên 630 tỉ USD. Ngoại thương then chốt. Đối tác: Trung Quốc, Hoa Kỳ, Hàn Quốc. Xuất: nông sản, thủy sản, khoáng sản, dệt may. Nhập: máy móc, hàng tiêu dùng. Hoạt động ngoại thương mạnh nhất: Xin-ga-po và Thái Lan. Nội vùng khoảng 25% tổng trị giá xuất nhập khẩu. Hầu hết các nước xuất siêu.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "3 · THƯƠNG MẠI",
			title: "Điều tiết sản xuất, nối khu vực với thế giới",
			tone: "sea",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-card px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-bold text-ink",
						children: "Nội thương"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-base leading-relaxed text-ink",
						children: "Phát triển nhanh: siêu thị, trung tâm thương mại, thương mại điện tử. Mạnh ở Xin-ga-po, In-đô-nê-xi-a, Ma-lai-xi-a và Thái Lan."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "rounded-2xl border border-line bg-card px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "text-lg font-bold text-ink",
						children: "Ngoại thương"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-base leading-relaxed text-ink",
						children: "Vai trò then chốt. Đối tác lớn nhất: Trung Quốc, Hoa Kỳ, Hàn Quốc. Xuất nông sản, thủy sản, khoáng sản, dệt may. Nhập máy móc, hàng tiêu dùng. Xin-ga-po và Thái Lan có hoạt động ngoại thương phát triển nhất."
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					value: "500 → 630",
					unit: "tỉ USD",
					label: "Thương mại nội khối ASEAN, từ năm 2010 đến năm 2020."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					value: "~25%",
					label: "Thương mại giữa các nước trong khu vực so với tổng trị giá xuất nhập khẩu toàn khu vực."
				})]
			})]
		})
	},
	{
		id: "table-123",
		title: "Bảng 12.3 — xuất nhập khẩu",
		fx: "fade",
		notes: "Đọc bảng rồi mới nhìn cột. Cả ba năm xuất lớn hơn nhập. Xuất siêu tính được: 125,5; 124,5 và 149,7 tỉ USD. Nói rõ đây là nhận xét tính từ bảng, khớp câu SGK: hầu hết các nước xuất siêu.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "BẢNG 12.3",
			title: "Trị giá xuất khẩu và nhập khẩu hàng hóa, dịch vụ",
			tone: "sea",
			source: "Đơn vị: tỉ USD. Giai đoạn 2010–2020. Nguồn: Ngân hàng Thế giới, 2022.",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DataTable, {
					headers: [
						"Trị giá",
						"2010",
						"2015",
						"2020"
					],
					rows: [[
						"Xuất khẩu",
						"1 244,9",
						"1 506,0",
						"1 676,3"
					], [
						"Nhập khẩu",
						"1 119,4",
						"1 381,5",
						"1 526,6"
					]]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GroupedColumns, {
					caption: "Xuất khẩu và nhập khẩu Đông Nam Á, tỉ USD",
					series: [{
						key: "x",
						name: "Xuất khẩu",
						tone: "gold"
					}, {
						key: "m",
						name: "Nhập khẩu",
						tone: "sea"
					}],
					groups: [
						{
							label: "2010",
							values: [{
								key: "x",
								value: 1244.9,
								display: "1 244,9"
							}, {
								key: "m",
								value: 1119.4,
								display: "1 119,4"
							}]
						},
						{
							label: "2015",
							values: [{
								key: "x",
								value: 1506,
								display: "1 506,0"
							}, {
								key: "m",
								value: 1381.5,
								display: "1 381,5"
							}]
						},
						{
							label: "2020",
							values: [{
								key: "x",
								value: 1676.3,
								display: "1 676,3"
							}, {
								key: "m",
								value: 1526.6,
								display: "1 526,6"
							}]
						}
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Remark, { children: "Cả ba mốc, xuất khẩu lớn hơn nhập khẩu. Xuất siêu tính từ bảng: 125,5 tỉ USD (2010), 124,5 (2015) và 149,7 (2020). Đúng với nhận định SGK: hầu hết các nước có trị giá xuất khẩu lớn hơn nhập khẩu." })]
		})
	},
	{
		id: "road-rail",
		title: "Đường bộ và đường sắt",
		fx: "rise",
		notes: "Vai trò chung của giao thông: sản xuất, đời sống, hội nhập, thu hút đầu tư. Đường bộ hiện đại hóa nhanh. Hành lang Đông – Tây nối Việt Nam, Lào, Thái Lan, Mi-an-ma. AH1, AH2, AH3. Đường sắt phổ biến ở lục địa, tổng 20 000 km năm 2020; Xin-ga-po và Ma-lai-xi-a nâng cấp cao tốc.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "3 · GIAO THÔNG",
			title: "Đường bộ và đường sắt nối sản xuất với hội nhập",
			tone: "sea",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
					"Giao thông được chú ý phát triển, hiện đại hóa để phục vụ sản xuất, đời sống và hợp tác với nhà đầu tư nước ngoài.",
					"Đường bộ đầu tư mạnh. Hành lang Đông – Tây nối Việt Nam, Lào, Thái Lan, Mi-an-ma.",
					"Các tuyến đường cao tốc Xuyên Á AH1, AH2, AH3 là những liên kết quan trọng trong khu vực.",
					"Đường sắt khá phổ biến ở Đông Nam Á lục địa. Tổng chiều dài 20 000 km (năm 2020).",
					"Xin-ga-po và Ma-lai-xi-a đang nâng cấp mạng lưới lên đường sắt cao tốc."
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 640 36",
					className: "w-full text-gold",
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
						x1: "8",
						y1: "18",
						x2: "632",
						y2: "18",
						className: "lane",
						stroke: "currentColor",
						strokeWidth: "3"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						"Việt Nam",
						"Lào",
						"Thái Lan",
						"Mi-an-ma",
						"AH1",
						"AH2",
						"AH3"
					].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: item }, item))
				})
			]
		})
	},
	{
		id: "sea-air",
		title: "Đường biển và hàng không",
		fx: "zoom",
		notes: "Đường biển rất quan trọng với khu vực biển đảo. 2,8 tỉ tấn năm 2019; hơn 500 cảng năm 2020. Đọc tên cảng đúng SGK. Xin-ga-po là một trong những cảng nhộn nhịp nhất thế giới. Hàng không: năm sân bay lớn được nêu.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "3 · BIỂN VÀ HÀNG KHÔNG",
			title: "Cảng biển và sân bay của một khu vực hướng biển",
			tone: "sea",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "2,8 tỉ tấn",
						label: "Khối lượng vận chuyển đường biển năm 2019."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						value: "> 500 cảng",
						label: "Số cảng biển của khu vực năm 2020."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid gap-3 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-line bg-card px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg font-bold text-ink",
							children: "Cảng biển lớn"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-base leading-relaxed text-ink",
							children: "Hải Phòng, Sài Gòn (Việt Nam), Y-an-gun (Mi-an-ma), Băng Cốc (Thái Lan), Xin-ga-po. Xin-ga-po là một trong những cảng biển nhộn nhịp nhất thế giới."
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-line bg-card px-4 py-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "text-lg font-bold text-ink",
							children: "Sân bay lớn"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-base leading-relaxed text-ink",
							children: "Chan-gi (Xin-ga-po), Xu-va-na-bu-mi (Thái Lan), Cu-a-la Lăm-pơ (Ma-lai-xi-a), Tân Sơn Nhất và Nội Bài (Việt Nam)."
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
					viewBox: "0 0 640 36",
					className: "w-full text-sea",
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M8 28 C 160 4, 480 4, 632 28",
						className: "lane",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "3"
					})
				})
			]
		})
	},
	{
		id: "finance",
		title: "Tài chính – ngân hàng",
		fx: "rise",
		notes: "Ngành đang trong quá trình phát triển và hội nhập, là động lực thúc đẩy kinh tế. Lợi thế: lao động và thị trường quy mô lớn. Năm trung tâm: Xin-ga-po, Cu-a-la Lăm-pơ, Băng Cốc, Gia-các-ta, Thành phố Hồ Chí Minh.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "3 · TÀI CHÍNH – NGÂN HÀNG",
			title: "Động lực hội nhập của những trung tâm lớn",
			tone: "sea",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Points, { items: [
				"Tài chính – ngân hàng đang trong quá trình phát triển và hội nhập với thế giới.",
				"Ngành dần trở thành động lực thúc đẩy kinh tế các nước trong khu vực.",
				"Thuận lợi về nguồn lao động và thị trường quy mô lớn đang thúc đẩy sự phát triển."
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					"Xin-ga-po",
					"Cu-a-la Lăm-pơ",
					"Băng Cốc",
					"Gia-các-ta",
					"Thành phố Hồ Chí Minh"
				].map((name) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Chip, { children: name }, name))
			})]
		})
	},
	{
		id: "tourism",
		title: "Du lịch — vai trò và số liệu",
		fx: "fade",
		notes: "Năm 2019: đóng góp hơn 393 tỉ USD vào GDP khu vực và thu hút khoảng 10% lượng khách du lịch quốc tế toàn cầu. Bốn nước du lịch mạnh. Nhấn năm 2019, không lấy năm dịch để thay số sách.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, {
			kicker: "3 · DU LỊCH",
			title: "Điểm đến phổ biến của khách quốc tế",
			tone: "sea",
			source: "Số liệu năm 2019 theo SGK Địa lí 11, Bài 12.",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					value: "> 393",
					unit: "tỉ USD, năm 2019",
					label: "Du lịch đóng góp vào GDP của khu vực."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					value: "~10%",
					unit: "khách quốc tế",
					label: "Đông Nam Á thu hút khoảng 10% tổng lượng khách du lịch quốc tế toàn cầu."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-base text-ink md:text-lg",
				children: "Các quốc gia có ngành du lịch phát triển mạnh: Thái Lan, Việt Nam, In-đô-nê-xi-a, Xin-ga-po."
			})]
		})
	},
	{
		id: "places",
		title: "Điểm du lịch tiêu biểu",
		fx: "zoom",
		notes: "Đọc sáu địa điểm đúng nước. Ảnh là Hình 12.5, bãi biển Ba-li, không phải một bãi biển khác. Câu luyện tập SGK gợi ý tìm hiểu thêm một địa điểm — có thể giao về nhà, không mở rộng trên slide.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, {
			kicker: "HÌNH 12.5",
			title: "Sáu điểm du lịch SGK nêu tên",
			tone: "sea",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SgkFigure, {
					src: "/sgk/hinh-12-5.jpg",
					alt: "Bãi biển Ba-li, In-đô-nê-xi-a",
					caption: "Hình 12.5. Bãi biển Ba-li, In-đô-nê-xi-a. Ảnh trong SGK."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-2",
					children: [
						["Ăng-co Vát", "Cam-pu-chia"],
						["Vịnh Hạ Long", "Việt Nam"],
						["Ba-li", "In-đô-nê-xi-a"],
						["Ba-gan", "Mi-an-ma"],
						["Cu-a-la Lăm-pơ", "Ma-lai-xi-a"],
						["Băng Cốc", "Thái Lan"]
					].map(([place, country]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center gap-3 rounded-2xl border border-line bg-card px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-5 shrink-0 text-gold" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-base text-ink md:text-lg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-semibold",
								children: place
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-muted",
								children: [" — ", country]
							})]
						})]
					}, place))
				})]
			})
		})
	},
	{
		id: "mind",
		title: "Sơ đồ tư duy",
		fx: "wipe",
		notes: "Dùng sơ đồ để khép bài, không thêm kiến thức mới. Đọc bốn nhánh, rồi một câu về lợi thế và thách thức. Có thể che nhánh và gọi học sinh nhắc lại.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mindmap, {})
	},
	{
		id: "quiz",
		title: "Câu hỏi củng cố",
		fx: "rise",
		notes: "Năm câu theo mức nhận biết, thông hiểu, vận dụng. Có thể bấm Hiện gợi ý ngay trên slide hoặc chuyển sang slide đáp án. Không để đáp án hiện sẵn khi mới mở.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quiz, {})
	},
	{
		id: "answers",
		title: "Gợi ý đáp án",
		fx: "fade",
		notes: "Slide dành cho người dạy. Có thể bỏ qua khi trình chiếu trước lớp và chỉ mở nếu cần chốt. Đáp án cũng nằm trong ghi chú của slide câu hỏi.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Answers, {})
	},
	{
		id: "end",
		title: "Kết thúc",
		fx: "zoom",
		notes: "Một câu chốt rồi dừng. Không mở rộng thành bài quảng bá du lịch. Mời học sinh về nhà quan sát lại Hình 12.2 và 12.3 trong sách.",
		node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EndSlide, {})
	}
];
function Deck() {
	const [index, setIndex] = (0, import_react.useState)(0);
	const [notes, setNotes] = (0, import_react.useState)(false);
	const [overview, setOverview] = (0, import_react.useState)(false);
	const start = (0, import_react.useRef)(null);
	const total = slides.length;
	const slide = slides[index] ?? slides[0];
	const go = (0, import_react.useCallback)((nextIndex) => {
		setIndex(Math.min(total - 1, Math.max(0, nextIndex)));
	}, [total]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;
			if (event.key === "ArrowRight" || event.key === "PageDown" || event.key === " ") {
				event.preventDefault();
				if (!overview) go(index + 1);
			} else if (event.key === "ArrowLeft" || event.key === "PageUp" || event.key === "Backspace") {
				event.preventDefault();
				if (!overview) go(index - 1);
			} else if (event.key === "Home") go(0);
			else if (event.key === "End") go(total - 1);
			else if (event.key === "n" || event.key === "N") setNotes((value) => !value);
			else if (event.key === "g" || event.key === "G") setOverview((value) => !value);
			else if (event.key === "Escape") {
				setOverview(false);
				setNotes(false);
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		go,
		index,
		overview,
		total
	]);
	const onPointerDown = (event) => {
		if (event.target.closest("button, a, input, textarea")) return;
		start.current = {
			x: event.clientX,
			y: event.clientY
		};
	};
	const onPointerUp = (event) => {
		if (!start.current || overview) return;
		const dx = event.clientX - start.current.x;
		const dy = event.clientY - start.current.y;
		start.current = null;
		if (Math.abs(dx) < 56 || Math.abs(dx) < Math.abs(dy)) return;
		go(index + (dx < 0 ? 1 : -1));
	};
	const fullscreen = async () => {
		try {
			if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
			else await document.exitFullscreen();
		} catch {}
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DeckNav.Provider, {
		value: {
			go,
			index
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "atlas flex h-dvh flex-col text-ink",
			onPointerDown,
			onPointerUp,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center justify-between gap-3 px-4 py-2 md:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-semibold tracking-wide text-gold",
						children: "Địa lí 11 · Bài 12"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm text-muted",
						children: slide.title
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-1 bg-deep",
					"aria-hidden": true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full bg-gold transition-[width] duration-500",
						style: { width: `${(index + 1) / total * 100}%` }
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-0 flex-1 flex-col lg:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
						className: "relative min-h-0 flex-1 overflow-hidden",
						"aria-live": "polite",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: `fx-${slide.fx} h-full overflow-y-auto`,
							children: slide.node
						}, slide.id), overview ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-0 z-20 overflow-y-auto bg-ocean/95 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-3 flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-bold",
									children: "Tất cả slide"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "rounded-full border border-line p-2",
									onClick: () => setOverview(false),
									"aria-label": "Đóng lưới slide",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid grid-cols-2 gap-2 md:grid-cols-3 lg:grid-cols-4",
								children: slides.map((item, itemIndex) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										go(itemIndex);
										setOverview(false);
									},
									className: `rounded-2xl border px-3 py-3 text-left ${itemIndex === index ? "border-gold bg-deep" : "border-line bg-card"}`,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm font-semibold text-gold",
										children: itemIndex + 1
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-1 block text-sm leading-snug text-ink",
										children: item.title
									})]
								}, item.id))
							})]
						}) : null]
					}), notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "max-h-48 shrink-0 overflow-y-auto border-t border-line bg-deep px-4 py-3 lg:max-h-none lg:w-80 lg:border-t-0 lg:border-l",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold text-gold",
							children: "Ghi chú thuyết trình"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-base leading-relaxed text-ink",
							children: slide.notes
						})]
					}) : null]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "flex items-center justify-between gap-2 border-t border-line px-3 py-2 pr-16 md:px-5 md:pr-24",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "rounded-full border border-line p-2",
								onClick: () => go(index - 1),
								disabled: index === 0,
								"aria-label": "Slide trước",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronLeft, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "min-w-16 text-center text-sm font-semibold",
								children: [
									index + 1,
									" / ",
									total
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "rounded-full border border-line p-2",
								onClick: () => go(index + 1),
								disabled: index === total - 1,
								"aria-label": "Slide sau",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-5" })
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: `rounded-full border px-3 py-2 text-sm font-semibold ${notes ? "border-gold text-gold" : "border-line"}`,
								onClick: () => setNotes((value) => !value),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StickyNote, { className: "mr-1 inline size-4" }), "Ghi chú"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "rounded-full border border-line p-2",
								onClick: () => setOverview(true),
								"aria-label": "Lưới slide",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutGrid, { className: "size-5" })
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "hidden rounded-full border border-line p-2 sm:block",
								onClick: fullscreen,
								"aria-label": "Toàn màn hình",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Maximize2, { className: "size-5" })
							})
						]
					})]
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Deck, {});
}
//#endregion
export { Home as component };
