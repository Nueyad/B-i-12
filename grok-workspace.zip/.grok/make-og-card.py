#!/usr/bin/env python3
"""Atlas-plate share card for Bài 12. Staged under .grok — never public/."""
import base64
import json
import math
from pathlib import Path

from PIL import ImageFont

ROOT = Path("/workspace/.grok")
GEO = ROOT / "countries50.geojson"
FONT_MED = ROOT / "fonts" / "BeVietnamPro-Medium.ttf"
FONT_BOLD = ROOT / "fonts" / "BeVietnamPro-Bold.ttf"
OUT_HTML = ROOT / "og-card.html"

ASEAN = {"BRN", "KHM", "IDN", "LAO", "MYS", "MMR", "PHL", "SGP", "THA", "TLS", "VNM"}

# Frame the whole region: Myanmar to the Philippines, north Vietnam to Timor.
LON0, LON1 = 92.2, 141.2
LAT0, LAT1 = -11.0, 23.6
LAT_REF = 6.0
COS = math.cos(math.radians(LAT_REF))

# Map plate sits above the lockup. Title stays in open lower margin.
L, T, R, B = 48, 22, 1152, 448

W_RAW = (LON1 - LON0) * COS
H_RAW = LAT1 - LAT0
BOX_W, BOX_H = R - L, B - T
SCALE = min(BOX_W / W_RAW, BOX_H / H_RAW)
USED_W, USED_H = W_RAW * SCALE, H_RAW * SCALE
OX = L + (BOX_W - USED_W) / 2
OY = T + (BOX_H - USED_H) / 2

CITIES = [
    (105.85, 21.03),  # Hà Nội
    (106.70, 10.78),  # TP. Hồ Chí Minh
    (100.50, 13.76),  # Băng Cốc
    (101.69, 3.14),   # Kuala Lumpur
    (103.85, 1.29),   # Xin-ga-po
    (106.83, -6.18),  # Gia-các-ta
    (120.98, 14.60),  # Ma-ni-la
    (104.93, 11.56),  # Phnôm Pênh
]


def project(lon, lat):
    x = OX + (lon - LON0) * COS * SCALE
    y = OY + (LAT1 - lat) * SCALE
    return x, y


def ring_hits(ring):
    lons = [p[0] for p in ring]
    lats = [p[1] for p in ring]
    if not lons:
        return False
    if max(lons) < LON0 - 1 or min(lons) > LON1 + 1:
        return False
    if max(lats) < LAT0 - 1 or min(lats) > LAT1 + 1:
        return False
    return True


def rings_of(geom):
    gtype = geom.get("type")
    coords = geom.get("coordinates") or []
    if gtype == "Polygon":
        yield coords
    elif gtype == "MultiPolygon":
        yield from coords
    elif gtype == "GeometryCollection":
        for g in geom.get("geometries") or []:
            yield from rings_of(g)


def path_for_polygon(poly):
    parts = []
    for ring in poly:
        if len(ring) < 3 or not ring_hits(ring):
            continue
        cmds = []
        for i, (lon, lat) in enumerate(ring):
            x, y = project(lon, lat)
            cmds.append(("M" if i == 0 else "L") + f"{x:.1f} {y:.1f}")
        parts.append(" ".join(cmds) + " Z")
    return " ".join(parts)


def feature_paths(feat):
    return [p for poly in rings_of(feat["geometry"]) if (p := path_for_polygon(poly))]


def b64(path: Path) -> str:
    return base64.b64encode(path.read_bytes()).decode()


def main():
    data = json.loads(GEO.read_text())
    asean_d = []
    near_d = []
    found = []
    for feat in data["features"]:
        props = feat.get("properties") or {}
        iso = props.get("ISO_A3") or props.get("ADM0_A3") or ""
        if iso in ("-99", None, ""):
            iso = props.get("ADM0_A3") or ""
        paths = feature_paths(feat)
        if not paths:
            continue
        # only keep features that actually drew something inside the plate
        blob = " ".join(paths)
        if iso in ASEAN:
            found.append(f"{iso}:{props.get('NAME')}")
            asean_d.append(blob)
        else:
            near_d.append(blob)

    print("ASEAN drawn:", ", ".join(found))
    print(f"scale px/deg {SCALE:.2f}  neighbors {len(near_d)}")

    graticule = []
    labels = []
    for lon in range(100, 141, 10):
        x1, y1 = project(lon, LAT1)
        x2, y2 = project(lon, LAT0)
        graticule.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}"/>')
        labels.append(
            f'<text x="{x1:.1f}" y="{y1 + 14:.1f}" text-anchor="middle">{lon}°Đ</text>'
        )
    for lat in range(-10, 21, 10):
        x1, y1 = project(LON0, lat)
        x2, y2 = project(LON1, lat)
        graticule.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}"/>')
        name = "0°" if lat == 0 else (f"{lat}°B" if lat > 0 else f"{abs(lat)}°N")
        labels.append(
            f'<text x="{x1 + 6:.1f}" y="{y1 - 4:.1f}" text-anchor="start">{name}</text>'
        )

    cities = []
    for lon, lat in CITIES:
        x, y = project(lon, lat)
        cities.append(
            f'<g transform="translate({x:.1f} {y:.1f})">'
            f'<circle r="7.2" fill="none" stroke="#e2b15a" stroke-width="0.8" opacity="0.7"/>'
            f'<circle r="3.1" fill="#e2b15a"/>'
            f'<circle r="1.15" fill="#f3efe4"/>'
            f"</g>"
        )

    # A few sea lanes between hubs, drawn under the dots.
    def lane(a, b):
        x1, y1 = project(*a)
        x2, y2 = project(*b)
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2 - 18
        return (
            f'<path d="M{x1:.1f} {y1:.1f} Q{mx:.1f} {my:.1f} {x2:.1f} {y2:.1f}" '
            f'fill="none" stroke="#e2b15a" stroke-width="1.15" '
            f'stroke-dasharray="1.5 4.5" stroke-linecap="round" opacity="0.55"/>'
        )

    lanes = [
        lane((103.85, 1.29), (120.98, 14.60)),
        lane((103.85, 1.29), (106.83, -6.18)),
        lane((103.85, 1.29), (106.70, 10.78)),
        lane((100.50, 13.76), (103.85, 1.29)),
    ]

    # 1 000 km scale bar in the open sea west of the plate (not on land).
    bar_px = (1000 / 110.95) * SCALE
    sx, sy = 68, 78
    scalebar = (
        f'<g fill="none" stroke="#f3efe4" stroke-width="1.35" opacity="0.85">'
        f'<line x1="{sx}" y1="{sy}" x2="{sx + bar_px:.1f}" y2="{sy}"/>'
        f'<line x1="{sx}" y1="{sy - 4}" x2="{sx}" y2="{sy + 4}"/>'
        f'<line x1="{sx + bar_px:.1f}" y1="{sy - 4}" x2="{sx + bar_px:.1f}" y2="{sy + 4}"/>'
        f"</g>"
        f'<text class="micro" x="{sx}" y="{sy + 15}" text-anchor="start">0</text>'
        f'<text class="micro" x="{sx + bar_px:.1f}" y="{sy + 15}" text-anchor="end">1 000 km</text>'
    )

    cx, cy = 1104, 102
    compass = f'''
    <g transform="translate({cx} {cy})">
      <circle r="24" fill="#07161d" fill-opacity="0.5" stroke="#2a9d8f" stroke-width="1.25"/>
      <circle r="16" fill="none" stroke="#f3efe4" stroke-opacity="0.28" stroke-width="0.6"/>
      <path d="M0 -16 L3.6 1 L0 -2.6 L-3.6 1 Z" fill="#e2b15a"/>
      <path d="M0 16 L-3.6 -1 L0 2.6 L3.6 -1 Z" fill="#3e9b5b"/>
      <circle r="1.9" fill="#f3efe4"/>
      <text class="micro" x="0" y="-30" text-anchor="middle">B</text>
    </g>
    '''

    med = b64(FONT_MED)
    bold = b64(FONT_BOLD)

    html = f'''<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="utf-8"/>
<style>
@font-face {{
  font-family: "Be Viet";
  src: url("data:font/ttf;base64,{med}") format("truetype");
  font-weight: 500;
}}
@font-face {{
  font-family: "Be Viet";
  src: url("data:font/ttf;base64,{bold}") format("truetype");
  font-weight: 700;
}}
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
html, body {{
  width: 1200px; height: 630px; overflow: hidden;
  background: #07161d;
  font-family: "Be Viet", "DejaVu Sans", sans-serif;
}}
.plate {{ position: relative; width: 1200px; height: 630px; }}
svg.atlas {{ position: absolute; inset: 0; width: 1200px; height: 630px; }}
.graticule {{ stroke: #f3efe4; stroke-opacity: 0.16; stroke-width: 0.7; }}
.labels text, text.micro {{
  font-family: "Be Viet", sans-serif;
  font-weight: 500;
  font-size: 11px;
  fill: #f3efe4;
  fill-opacity: 0.62;
}}
.lockup {{
  position: absolute;
  left: 0; right: 0;
  top: 478px;
  text-align: center;
  color: #f3efe4;
}}
.eyebrow {{
  font-weight: 500;
  font-size: 20px;
  letter-spacing: 0.34em;
  color: #e2b15a;
  text-indent: 0.34em;
}}
.rule {{
  width: 72px; height: 2px; margin: 12px auto 14px;
  background: #e2b15a;
  border-radius: 1px;
}}
.title {{
  font-weight: 700;
  font-size: 46px;
  line-height: 1.05;
  letter-spacing: -0.015em;
  color: #f3efe4;
  text-shadow: 0 2px 18px rgba(7, 22, 29, 0.55);
}}
</style>
</head>
<body>
<div class="plate">
<svg class="atlas" viewBox="0 0 1200 630" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <radialGradient id="sea" cx="48%" cy="40%" r="75%">
      <stop offset="0" stop-color="#14535a"/>
      <stop offset="0.42" stop-color="#0c3038"/>
      <stop offset="1" stop-color="#07161d"/>
    </radialGradient>
    <linearGradient id="land" x1="0" y1="0" x2="0.2" y2="1">
      <stop offset="0" stop-color="#6fbf78"/>
      <stop offset="0.45" stop-color="#3e9b5b"/>
      <stop offset="1" stop-color="#1d6a42"/>
    </linearGradient>
    <linearGradient id="near" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#1c4a52"/>
      <stop offset="1" stop-color="#102e36"/>
    </linearGradient>
    <linearGradient id="scrim" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0.62" stop-color="#07161d" stop-opacity="0"/>
      <stop offset="0.78" stop-color="#07161d" stop-opacity="0.55"/>
      <stop offset="1" stop-color="#07161d" stop-opacity="0.94"/>
    </linearGradient>
    <clipPath id="plate">
      <rect x="{L}" y="{T}" width="{BOX_W}" height="{BOX_H}"/>
    </clipPath>
    <filter id="landshadow" x="-15%" y="-15%" width="130%" height="140%">
      <feDropShadow dx="0" dy="5" stdDeviation="3.5" flood-color="#031016" flood-opacity="0.7"/>
    </filter>
  </defs>
  <rect width="1200" height="630" fill="url(#sea)"/>
  <g clip-path="url(#plate)">
    <g class="graticule">{''.join(graticule)}</g>
    <g fill="url(#near)" stroke="#07161d" stroke-width="0.6">{''.join(f'<path d="{p}"/>' for p in near_d)}</g>
    <g filter="url(#landshadow)">
      <g fill="url(#land)" stroke="#e7f2e4" stroke-width="1.15" stroke-linejoin="round">
        {''.join(f'<path d="{p}"/>' for p in asean_d)}
      </g>
    </g>
    <g fill="none" stroke="#e2b15a" stroke-opacity="0.55" stroke-width="0.7" stroke-linejoin="round">
      {''.join(f'<path d="{p}"/>' for p in asean_d)}
    </g>
    {''.join(lanes)}
    {''.join(cities)}
  </g>
  <g class="labels">{''.join(labels)}</g>
  {scalebar}
  {compass}
  <rect width="1200" height="630" fill="url(#scrim)"/>
</svg>
<div class="lockup">
  <div class="eyebrow">Địa lí 11</div>
  <div class="rule"></div>
  <div class="title">Bài 12 — Kinh tế Đông Nam Á</div>
</div>
</div>
</body>
</html>
'''
    OUT_HTML.write_text(html, encoding="utf-8")
    # Sanity: title width inside the safe half-to-two-thirds band.
    font = ImageFont.truetype(str(FONT_BOLD), 46)
    width = font.getlength("Bài 12 — Kinh tế Đông Nam Á")
    print(f"title px {width:.0f} (band 600–800 ideal on 1200)")
    print("wrote", OUT_HTML, "bytes", OUT_HTML.stat().st_size)


if __name__ == "__main__":
    main()
